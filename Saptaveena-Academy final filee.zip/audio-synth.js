/**
 * Saptaveena Academy - Web Audio Synthesizer Engine
 * 1. Indian Harmonium Reed Simulation
 * 2. Acoustic Guitar Pluck & Strum Engine
 */

class SoundEngine {
    constructor() {
        this.ctx = null;
        this.activeHarmoniumNotes = {};
        this.masterVolume = 0.7;
        this.isMuted = false;
        this.isPlayingMelody = false;
    }

    init() {
        if (!this.ctx) {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            this.ctx = new AudioContext();
        }
        if (this.ctx.state === 'suspended') {
            this.ctx.resume();
        }
    }

    // Sound ON / OFF Control
    setMuted(muted) {
        this.isMuted = !!muted;
        if (this.isMuted) {
            this.stopAllHarmoniumNotes();
            this.stopMelody();
        }
        return this.isMuted;
    }

    toggleMute() {
        return this.setMuted(!this.isMuted);
    }

    // Complete Audio Reset
    resetAll() {
        this.stopMelody();
        this.stopAllHarmoniumNotes();
        if (this.ctx && this.ctx.state === 'suspended') {
            this.ctx.resume();
        }
    }

    // Stop all active vibrating notes immediately
    stopAllHarmoniumNotes() {
        if (this.activeHarmoniumNotes) {
            Object.keys(this.activeHarmoniumNotes).forEach(freq => {
                const note = this.activeHarmoniumNotes[freq];
                if (note) {
                    try {
                        note.osc1.stop();
                        note.osc2.stop();
                        note.osc3.stop();
                        note.osc1.disconnect();
                        note.osc2.disconnect();
                        note.osc3.disconnect();
                        note.gainNode.disconnect();
                    } catch (e) {}
                }
            });
            this.activeHarmoniumNotes = {};
        }
    }

    // --- HARMONIUM SYNTHESIS ---
    playHarmoniumNote(freq, noteName = '') {
        if (this.isMuted) return; // Silent practice mode when sound is OFF
        this.init();
        if (this.activeHarmoniumNotes[freq]) {
            this.stopHarmoniumNote(freq);
        }

        const now = this.ctx.currentTime;
        
        // Harmonium uses free reeds with rich odd/even harmonics.
        // We blend two detuned oscillators (Sawtooth + Square) to give that warm reed chorusing.
        const osc1 = this.ctx.createOscillator();
        const osc2 = this.ctx.createOscillator();
        const osc3 = this.ctx.createOscillator();

        osc1.type = 'sawtooth';
        osc1.frequency.setValueAtTime(freq, now);

        osc2.type = 'square';
        osc2.frequency.setValueAtTime(freq * 1.002, now); // slight detune for accordion/reed warmth

        osc3.type = 'sawtooth';
        osc3.frequency.setValueAtTime(freq * 0.5, now); // Sub-octave reed for body

        // Harmonium air filter (removes harsh digital treble, simulates wooden cabinet resonance)
        const filter = this.ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(1400, now);
        filter.Q.setValueAtTime(2.5, now);

        // Bellows envelope
        const gainNode = this.ctx.createGain();
        gainNode.gain.setValueAtTime(0, now);
        // Soft attack (air pumped into reed chamber)
        gainNode.gain.linearRampToValueAtTime(0.22 * this.masterVolume, now + 0.08);

        // Sub gain
        const subGain = this.ctx.createGain();
        subGain.gain.setValueAtTime(0.12 * this.masterVolume, now);

        osc1.connect(filter);
        osc2.connect(filter);
        osc3.connect(subGain);
        subGain.connect(filter);

        filter.connect(gainNode);
        gainNode.connect(this.ctx.destination);

        osc1.start(now);
        osc2.start(now);
        osc3.start(now);

        this.activeHarmoniumNotes[freq] = { osc1, osc2, osc3, gainNode, filter };
    }

    stopHarmoniumNote(freq) {
        if (!this.ctx || !this.activeHarmoniumNotes[freq]) return;
        const note = this.activeHarmoniumNotes[freq];
        const now = this.ctx.currentTime;

        // Bellows release
        note.gainNode.gain.cancelScheduledValues(now);
        note.gainNode.gain.setValueAtTime(note.gainNode.gain.value, now);
        note.gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 0.15);

        setTimeout(() => {
            try {
                note.osc1.stop();
                note.osc2.stop();
                note.osc3.stop();
                note.osc1.disconnect();
                note.osc2.disconnect();
                note.osc3.disconnect();
                note.gainNode.disconnect();
            } catch (e) {}
            delete this.activeHarmoniumNotes[freq];
        }, 180);
    }

    // --- GUITAR STRING SYNTHESIS ---
    playGuitarPluck(freq, delay = 0) {
        if (this.isMuted) return;
        this.init();
        const startTime = this.ctx.currentTime + delay;

        // Acoustic guitar simulation using decaying shaped oscillators
        const osc = this.ctx.createOscillator();
        const osc2 = this.ctx.createOscillator();
        const gainNode = this.ctx.createGain();
        const filter = this.ctx.createBiquadFilter();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, startTime);

        osc2.type = 'sawtooth';
        osc2.frequency.setValueAtTime(freq * 2, startTime); // Harmonic overtone

        // Guitar acoustic body resonance
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(freq * 1.8, startTime);
        filter.Q.setValueAtTime(1.8, startTime);

        const mixGain = this.ctx.createGain();
        mixGain.gain.setValueAtTime(0.3, startTime);
        osc2.connect(mixGain);
        mixGain.connect(gainNode);

        osc.connect(gainNode);
        gainNode.connect(filter);
        filter.connect(this.ctx.destination);

        // Acoustic guitar pluck envelope: immediate sharp strike, followed by exponential wooden body ring
        gainNode.gain.setValueAtTime(0.001, startTime);
        gainNode.gain.exponentialRampToValueAtTime(0.35 * this.masterVolume, startTime + 0.005);
        gainNode.gain.exponentialRampToValueAtTime(0.0001, startTime + 2.2);

        osc.start(startTime);
        osc2.start(startTime);
        osc.stop(startTime + 2.3);
        osc2.stop(startTime + 2.3);
    }

    // Get frequencies for any chord from standard guitar tuning (6: Low E -> 1: High E)
    getChordFrequencies(chordName) {
        const stringBaseFreqs = {
            6: 82.41,   // E2 (Low E)
            5: 110.00,  // A2
            4: 146.83,  // D3
            3: 196.00,  // G3
            2: 246.94,  // B3
            1: 329.63   // E4 (High E)
        };

        let freqs = [];

        if (typeof GUITAR_CHORD_DATA !== 'undefined' && GUITAR_CHORD_DATA[chordName]) {
            const chord = GUITAR_CHORD_DATA[chordName];
            // Order strings from bass (6) to treble (1)
            for (let s = 6; s >= 1; s--) {
                const pos = chord.fretPositions.find(p => p.string === s);
                if (pos && pos.fret !== 'x') {
                    const fretNum = typeof pos.fret === 'number' ? pos.fret : parseInt(pos.fret, 10);
                    if (!isNaN(fretNum)) {
                        const freq = stringBaseFreqs[s] * Math.pow(2, fretNum / 12);
                        freqs.push({ string: s, freq: freq });
                    }
                }
            }
        }

        // Fallback standard C Major frequencies if empty
        if (freqs.length === 0) {
            const fallbackTable = {
                'C':  [130.81, 164.81, 196.00, 261.63, 329.63],
                'G':  [98.00, 123.47, 146.83, 196.00, 293.66, 392.00],
                'D':  [146.83, 220.00, 293.66, 369.99],
                'Em': [82.41, 123.47, 164.81, 196.00, 246.94, 329.63],
                'Am': [110.00, 164.81, 220.00, 261.63, 329.63],
                'F':  [87.31, 130.81, 174.61, 220.00, 261.63, 349.23],
                'Dm': [146.83, 220.00, 293.66, 349.23],
                'E':  [82.41, 123.47, 164.81, 207.65, 246.94, 329.63]
            };
            const list = fallbackTable[chordName] || fallbackTable['C'];
            freqs = list.map((f, i) => ({ string: 5 - i, freq: f }));
        }

        return freqs;
    }

    // Strum a chord (Downstroke or Upstroke)
    strumGuitarChord(chordName, direction = 'down', speed = 0.032) {
        if (this.isMuted) return;
        this.init();

        const chordFreqObjects = this.getChordFrequencies(chordName);
        let freqs = chordFreqObjects.map(item => item.freq);

        // 'up' stroke: treble (high E) to bass (low E)
        if (direction === 'up') {
            freqs = freqs.slice().reverse();
        }

        freqs.forEach((freq, idx) => {
            this.playGuitarPluck(freq, idx * speed);
        });
    }

    // Pluck chord string-by-string (Arpeggio)
    async pluckArpeggio(chordName, speed = 0.15) {
        if (this.isMuted) return;
        this.init();

        const chordFreqObjects = this.getChordFrequencies(chordName);
        for (let i = 0; i < chordFreqObjects.length; i++) {
            this.playGuitarPluck(chordFreqObjects[i].freq, 0);
            await new Promise(r => setTimeout(r, speed * 1000));
        }
    }

    // --- BEAT BOX & ACOUSTIC PERCUSSION SYNTHESIS ---
    getNoiseBuffer() {
        if (this.noiseBuffer) return this.noiseBuffer;
        this.init();
        const bufferSize = this.ctx.sampleRate * 2; // 2 seconds
        const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
        const output = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
            output[i] = Math.random() * 2 - 1;
        }
        this.noiseBuffer = buffer;
        return this.noiseBuffer;
    }

    // 1. Kick Drum (Punchy Low-end Thump)
    playKick(time = 0) {
        if (this.isMuted) return;
        this.init();
        const now = (time > 0 ? time : this.ctx.currentTime);
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(150, now);
        osc.frequency.exponentialRampToValueAtTime(32, now + 0.12);

        gain.gain.setValueAtTime(0.85 * this.masterVolume, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.32);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(now);
        osc.stop(now + 0.33);
    }

    // 2. Snare Drum / Rimshot Slap
    playSnare(time = 0) {
        if (this.isMuted) return;
        this.init();
        const now = (time > 0 ? time : this.ctx.currentTime);

        // Filtered noise snap
        const noise = this.ctx.createBufferSource();
        noise.buffer = this.getNoiseBuffer();
        const noiseFilter = this.ctx.createBiquadFilter();
        noiseFilter.type = 'highpass';
        noiseFilter.frequency.setValueAtTime(1000, now);

        const noiseGain = this.ctx.createGain();
        noiseGain.gain.setValueAtTime(0.65 * this.masterVolume, now);
        noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);

        noise.connect(noiseFilter);
        noiseFilter.connect(noiseGain);
        noiseGain.connect(this.ctx.destination);

        // Body tone
        const osc = this.ctx.createOscillator();
        const oscGain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(180, now);
        osc.frequency.exponentialRampToValueAtTime(80, now + 0.08);

        oscGain.gain.setValueAtTime(0.5 * this.masterVolume, now);
        oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);

        osc.connect(oscGain);
        oscGain.connect(this.ctx.destination);

        noise.start(now);
        osc.start(now);
        noise.stop(now + 0.2);
        osc.stop(now + 0.12);
    }

    // 3. Hi-Hat / Acoustic Shaker
    playHiHat(time = 0, isOpen = false) {
        if (this.isMuted) return;
        this.init();
        const now = (time > 0 ? time : this.ctx.currentTime);

        const noise = this.ctx.createBufferSource();
        noise.buffer = this.getNoiseBuffer();

        const filter = this.ctx.createBiquadFilter();
        filter.type = 'highpass';
        filter.frequency.setValueAtTime(7500, now);

        const gain = this.ctx.createGain();
        const decay = isOpen ? 0.25 : 0.05;
        gain.gain.setValueAtTime(0.35 * this.masterVolume, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + decay);

        noise.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);

        noise.start(now);
        noise.stop(now + decay + 0.01);
    }

    // 4. Wood Block / Metronome Click
    playWoodBlock(time = 0, isHigh = false) {
        if (this.isMuted) return;
        this.init();
        const now = (time > 0 ? time : this.ctx.currentTime);

        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        const filter = this.ctx.createBiquadFilter();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(isHigh ? 1200 : 800, now);

        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(isHigh ? 1200 : 800, now);
        filter.Q.setValueAtTime(5, now);

        gain.gain.setValueAtTime(0.6 * this.masterVolume, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.06);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(now);
        osc.stop(now + 0.07);
    }

    // --- BEAT BOX SCHEDULER ---
    startBeatBox(pattern = 'folk4', bpm = 95, onBeatTick = null) {
        this.stopBeatBox();
        this.isBeatBoxRunning = true;

        const beatInterval = (60 / bpm) * 1000;
        let beatIndex = 0;
        const totalBeats = (pattern === 'waltz3' ? 3 : (pattern === 'ballad68' ? 6 : 4));

        const tick = () => {
            if (!this.isBeatBoxRunning) return;

            // Trigger percussion based on pattern & beatIndex
            if (pattern === 'folk4') {
                if (beatIndex === 0) {
                    this.playKick();
                    this.playHiHat();
                } else if (beatIndex === 1) {
                    this.playSnare();
                    this.playHiHat();
                } else if (beatIndex === 2) {
                    this.playKick();
                    this.playHiHat();
                } else if (beatIndex === 3) {
                    this.playSnare();
                    this.playHiHat();
                }
            } else if (pattern === 'ballad4') {
                if (beatIndex === 0 || beatIndex === 2) {
                    this.playKick();
                } else {
                    this.playSnare();
                }
                this.playHiHat();
            } else if (pattern === 'waltz3') {
                if (beatIndex === 0) {
                    this.playKick();
                } else {
                    this.playWoodBlock(0, false);
                }
                this.playHiHat();
            } else if (pattern === 'ballad68') {
                if (beatIndex === 0) {
                    this.playKick();
                } else if (beatIndex === 3) {
                    this.playSnare();
                }
                this.playHiHat();
            } else if (pattern === 'reggae') {
                if (beatIndex === 1 || beatIndex === 3) {
                    this.playHiHat(0, true);
                }
                if (beatIndex === 2) {
                    this.playSnare();
                }
            } else if (pattern === 'metronome') {
                this.playWoodBlock(0, beatIndex === 0);
            }

            if (onBeatTick) {
                onBeatTick(beatIndex, totalBeats);
            }

            beatIndex = (beatIndex + 1) % totalBeats;
            this.beatBoxTimer = setTimeout(tick, beatInterval);
        };

        tick();
    }

    stopBeatBox() {
        this.isBeatBoxRunning = false;
        if (this.beatBoxTimer) {
            clearTimeout(this.beatBoxTimer);
            this.beatBoxTimer = null;
        }
    }

    // --- STRUMMING PATTERN SCHEDULER ---
    playStrumPattern(chordName, strokes, bpm = 95, isLoop = false, onStrokeTick = null, onFinish = null) {
        this.stopStrumPattern();
        this.isStrummingRunning = true;

        if (!strokes || strokes.length === 0) return;

        // In 4/4 eighth-note division, step interval = (60 / bpm) / 2 * 1000 ms
        const strokeInterval = ((60 / bpm) / 2) * 1000;
        let strokeIdx = 0;

        const tick = () => {
            if (!this.isStrummingRunning) {
                if (onFinish) onFinish();
                return;
            }

            const stroke = strokes[strokeIdx];

            if (stroke.type === 'down') {
                this.strumGuitarChord(chordName, 'down', 0.03);
            } else if (stroke.type === 'up') {
                this.strumGuitarChord(chordName, 'up', 0.024);
            }

            if (onStrokeTick) {
                onStrokeTick(stroke, strokeIdx);
            }

            strokeIdx++;

            if (strokeIdx >= strokes.length) {
                if (isLoop && this.isStrummingRunning) {
                    strokeIdx = 0;
                    this.strummingTimer = setTimeout(tick, strokeInterval);
                } else {
                    this.isStrummingRunning = false;
                    setTimeout(() => {
                        if (onFinish) onFinish();
                    }, strokeInterval);
                }
            } else {
                this.strummingTimer = setTimeout(tick, strokeInterval);
            }
        };

        tick();
    }

    stopStrumPattern() {
        this.isStrummingRunning = false;
        if (this.strummingTimer) {
            clearTimeout(this.strummingTimer);
            this.strummingTimer = null;
        }
    }

    // Stop all melodies and patterns
    stopMelody() {
        this.isPlayingMelody = false;
        this.stopBeatBox();
        this.stopStrumPattern();
        if (this.activeHarmoniumNotes) {
            Object.keys(this.activeHarmoniumNotes).forEach(freq => {
                this.stopHarmoniumNote(Number(freq));
            });
        }
    }

    // Play Raga sequence helper with progress callback and cancel support
    async playMelody(notes, delayBetween = 450, onProgress = null) {
        this.stopMelody();
        this.isPlayingMelody = true;

        for (let i = 0; i < notes.length; i++) {
            if (!this.isPlayingMelody) break;
            const note = notes[i];

            if (onProgress) {
                onProgress(note, i, true);
            }
            this.playHarmoniumNote(note.freq, note.name || note.swar);

            await new Promise(r => setTimeout(r, Math.max(80, delayBetween - 50)));

            this.stopHarmoniumNote(note.freq);
            if (onProgress) {
                onProgress(note, i, false);
            }

            await new Promise(r => setTimeout(r, 50));
        }

        this.isPlayingMelody = false;
    }
}

// Export singleton instance
window.soundEngine = new SoundEngine();
