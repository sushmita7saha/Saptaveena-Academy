/**
 * Saptaveena Academy - Master Application Engine
 * Orchestrates navigation, virtual classroom, whiteboard, audio synthesis,
 * student database, certificate generator, payment gateway & receipt generation.
 */

document.addEventListener('DOMContentLoaded', () => {
    initNavigation();
    initQRCodes();
    initVirtualClassroom();
    initWhiteboard();
    initGuitarVisualizer();
    initHarmoniumKeyboard();
    initCertGenerator();
    initStudentDatabase();
    initPaymentGateway();
    initMentoringBooking();
    initParentPortal();
    initScheduleFilter();
    initModals();
});

// ==========================================
// 1. Navigation & Mobile Drawer
// ==========================================
function initNavigation() {
    const mobileToggle = document.getElementById('mobileNavToggle');
    const mobileDrawer = document.getElementById('mobileNavDrawer');
    const navLinks = document.querySelectorAll('.nav-link, .mobile-link');

    if (mobileToggle && mobileDrawer) {
        mobileToggle.addEventListener('click', () => {
            mobileDrawer.classList.toggle('active');
        });

        // Close on link click
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                mobileDrawer.classList.remove('active');
            });
        });
    }

    // Smooth scroll offset adjustment
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            const targetId = link.getAttribute('href');
            if (targetId && targetId.startsWith('#')) {
                e.preventDefault();
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    const headerHeight = document.querySelector('.site-header').offsetHeight;
                    const targetPosition = targetElement.getBoundingClientRect().top + window.pageYOffset - headerHeight - 10;
                    window.scrollTo({
                        top: targetPosition,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
}

// ==========================================
// 2. QR Code Rendering Engine
// ==========================================
function initQRCodes() {
    // 1. Hero Poster QR Code (Registration link / UPI)
    const posterQREl = document.getElementById('posterQRCode');
    if (posterQREl && window.QRCode) {
        new QRCode(posterQREl, {
            text: "upi://pay?pa=education.saha7@oksbi&pn=Sushmita%20Saha&am=449&cu=INR",
            width: 96,
            height: 96,
            colorDark: "#4a0d17",
            colorLight: "#ffffff"
        });
    }

    // 2. Main Payment Section QR Code
    updatePaymentQR(449);
}

function updatePaymentQR(amount = 449) {
    const paymentQREl = document.getElementById('paymentGatewayQR');
    if (paymentQREl && window.QRCode) {
        paymentQREl.innerHTML = '';
        const upiString = `upi://pay?pa=education.saha7@oksbi&pn=Sushmita%20Saha&am=${amount}&cu=INR`;
        new QRCode(paymentQREl, {
            text: upiString,
            width: 196,
            height: 196,
            colorDark: "#3b0912",
            colorLight: "#ffffff"
        });

        const qrSubtext = document.getElementById('qrAmountLabel');
        if (qrSubtext) {
            qrSubtext.textContent = `₹${amount}/- (Payee: Sushmita Saha • UPI: education.saha7@oksbi)`;
        }
    }
}

// ==========================================
// 3. Virtual Classroom & Live Stage
// ==========================================
function initVirtualClassroom() {
    const tabBtns = document.querySelectorAll('.v-tab-btn');
    const tabPanes = document.querySelectorAll('.virtual-tab-pane');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            tabBtns.forEach(b => b.classList.remove('active'));
            tabPanes.forEach(p => p.classList.remove('active'));

            btn.classList.add('active');
            const targetPaneId = btn.getAttribute('data-tab');
            const targetPane = document.getElementById(targetPaneId);
            if (targetPane) {
                targetPane.classList.add('active');
                if (targetPaneId === 'tabWhiteboard') {
                    resizeWhiteboardCanvas();
                }
            }
        });
    });

    // Mock Live Chat
    const chatInput = document.getElementById('liveChatInput');
    const chatSendBtn = document.getElementById('liveChatSendBtn');
    const chatMessages = document.getElementById('liveChatMessages');

    function sendChatMessage() {
        if (!chatInput || !chatInput.value.trim()) return;
        const msgText = chatInput.value.trim();
        const msgEl = document.createElement('div');
        msgEl.className = 'chat-bubble';
        msgEl.innerHTML = `
            <div class="author">You (Student)</div>
            <div>${escapeHTML(msgText)}</div>
        `;
        chatMessages.appendChild(msgEl);
        chatInput.value = '';
        chatMessages.scrollTop = chatMessages.scrollHeight;

        // Auto simulated mentor reply after 1.5s
        setTimeout(() => {
            const replies = [
                "Excellent observation! Pay attention to the wrist posture here.",
                "Yes, that's the correct swar sequence for Raga Yaman.",
                "Beautiful color contrast! Keep the strokes fluid.",
                "Make sure the ring finger stays on the 3rd fret."
            ];
            const randomReply = replies[Math.floor(Math.random() * replies.length)];
            const mentorEl = document.createElement('div');
            mentorEl.className = 'chat-bubble';
            mentorEl.innerHTML = `
                <div class="author" style="color: #f59e0b;">Sushmita Saha (Director &amp; Chief Academic Mentor)</div>
                <div>${randomReply}</div>
            `;
            chatMessages.appendChild(mentorEl);
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }, 1200);
    }

    if (chatSendBtn && chatInput) {
        chatSendBtn.addEventListener('click', sendChatMessage);
        chatInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') sendChatMessage();
        });
    }

    // Video Controls Mock
    const micBtn = document.getElementById('ctrlMicBtn');
    const camBtn = document.getElementById('ctrlCamBtn');
    if (micBtn) {
        micBtn.addEventListener('click', () => {
            micBtn.classList.toggle('active');
            micBtn.style.background = micBtn.classList.contains('active') ? '#dc2626' : '';
        });
    }
    if (camBtn) {
        camBtn.addEventListener('click', () => {
            camBtn.classList.toggle('active');
            camBtn.style.background = camBtn.classList.contains('active') ? '#dc2626' : '';
        });
    }
}

// ==========================================
// 4. Interactive Whiteboard for Art (Freehand & Easy Shapes)
// ==========================================
let wbCtx = null;
let isDrawing = false;
let currentTool = 'brush';
let currentColor = '#1f1a1b';
let currentBrushSize = 4;
let isShapeFill = false;
let startX = 0;
let startY = 0;
let canvasSnapshot = null;
const undoStack = [];
const SHAPE_TOOLS = ['line', 'curve', 'square', 'rectangle', 'circle', 'triangle', 'flower', 'star', 'heart'];

function initWhiteboard() {
    const canvas = document.getElementById('artWhiteboardCanvas');
    if (!canvas) return;

    wbCtx = canvas.getContext('2d');
    resizeWhiteboardCanvas();
    window.addEventListener('resize', resizeWhiteboardCanvas);

    // Initial canvas setup
    wbCtx.fillStyle = '#ffffff';
    wbCtx.fillRect(0, 0, canvas.width, canvas.height);
    saveUndoState();

    // Drawing Listeners
    canvas.addEventListener('mousedown', startDrawing);
    canvas.addEventListener('mousemove', draw);
    canvas.addEventListener('mouseup', stopDrawing);
    canvas.addEventListener('mouseleave', stopDrawing);

    // Touch support for tablets/mobile
    canvas.addEventListener('touchstart', (e) => {
        e.preventDefault();
        const touch = e.touches[0];
        startDrawing({ clientX: touch.clientX, clientY: touch.clientY });
    });
    canvas.addEventListener('touchmove', (e) => {
        e.preventDefault();
        const touch = e.touches[0];
        draw({ clientX: touch.clientX, clientY: touch.clientY });
    });
    canvas.addEventListener('touchend', stopDrawing);

    // Color Swatches
    const swatches = document.querySelectorAll('.wb-color-swatch');
    swatches.forEach(swatch => {
        swatch.addEventListener('click', () => {
            swatches.forEach(s => s.classList.remove('active'));
            swatch.classList.add('active');
            currentColor = swatch.getAttribute('data-color');
            if (currentTool === 'eraser') setTool('brush');
        });
    });

    // Tool Buttons (Brush, Shade, Eraser & Shapes)
    const toolBtns = document.querySelectorAll('.wb-tool-btn[data-tool]');
    toolBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            toolBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            setTool(btn.getAttribute('data-tool'));
        });
    });

    // Shape Fill Mode Toggle
    const fillToggleBtn = document.getElementById('wbFillToggleBtn');
    if (fillToggleBtn) {
        fillToggleBtn.addEventListener('click', () => {
            isShapeFill = !isShapeFill;
            fillToggleBtn.classList.toggle('active', isShapeFill);
            const icon = document.getElementById('wbFillIcon');
            const label = document.getElementById('wbFillLabel');
            if (icon) icon.textContent = isShapeFill ? '⬛' : '🔲';
            if (label) label.textContent = isShapeFill ? 'Filled' : 'Outline';
        });
    }

    // Brush Size Slider
    const brushSlider = document.getElementById('wbBrushSize');
    if (brushSlider) {
        brushSlider.addEventListener('input', (e) => {
            currentBrushSize = parseInt(e.target.value, 10) || 4;
        });
    }

    // Undo Button
    const undoBtn = document.getElementById('wbUndoBtn');
    if (undoBtn) {
        undoBtn.addEventListener('click', undoWhiteboard);
    }

    // Clear Button
    const clearBtn = document.getElementById('wbClearBtn');
    if (clearBtn) {
        clearBtn.addEventListener('click', () => {
            if (confirm("Are you sure you want to clear your artwork?")) {
                wbCtx.fillStyle = '#ffffff';
                wbCtx.fillRect(0, 0, canvas.width, canvas.height);
                saveUndoState();
            }
        });
    }

    // Download Artwork (PNG)
    const downloadBtn = document.getElementById('wbDownloadBtn');
    if (downloadBtn) {
        downloadBtn.addEventListener('click', () => {
            const dataUrl = canvas.toDataURL('image/png');
            const link = document.createElement('a');
            link.download = `saptaveena-art-${Date.now()}.png`;
            link.href = dataUrl;
            link.click();
        });
    }
}

function saveUndoState() {
    const canvas = document.getElementById('artWhiteboardCanvas');
    if (!canvas || !wbCtx) return;
    try {
        const state = wbCtx.getImageData(0, 0, canvas.width, canvas.height);
        undoStack.push(state);
        if (undoStack.length > 25) {
            undoStack.shift();
        }
    } catch (err) {
        console.error("Undo snapshot error:", err);
    }
}

function undoWhiteboard() {
    const canvas = document.getElementById('artWhiteboardCanvas');
    if (!canvas || !wbCtx) return;
    if (undoStack.length > 1) {
        undoStack.pop(); // Remove active state
        const prevState = undoStack[undoStack.length - 1];
        wbCtx.putImageData(prevState, 0, 0);
    } else if (undoStack.length === 1) {
        wbCtx.fillStyle = '#ffffff';
        wbCtx.fillRect(0, 0, canvas.width, canvas.height);
        undoStack.length = 0;
        saveUndoState();
    }
}

function resizeWhiteboardCanvas() {
    const canvas = document.getElementById('artWhiteboardCanvas');
    if (!canvas) return;
    const rect = canvas.parentElement.getBoundingClientRect();
    if (rect.width > 0) {
        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = canvas.width;
        tempCanvas.height = canvas.height;
        const tempCtx = tempCanvas.getContext('2d');
        tempCtx.drawImage(canvas, 0, 0);

        canvas.width = rect.width;
        canvas.height = 480;

        wbCtx.fillStyle = '#ffffff';
        wbCtx.fillRect(0, 0, canvas.width, canvas.height);
        wbCtx.drawImage(tempCanvas, 0, 0);
        saveUndoState();
    }
}

function setTool(tool) {
    currentTool = tool;
}

function startDrawing(e) {
    const canvas = document.getElementById('artWhiteboardCanvas');
    if (!canvas || !wbCtx) return;
    const pos = getCanvasPos(e);
    isDrawing = true;
    startX = pos.x;
    startY = pos.y;

    if (SHAPE_TOOLS.includes(currentTool)) {
        canvasSnapshot = wbCtx.getImageData(0, 0, canvas.width, canvas.height);
    } else {
        wbCtx.beginPath();
        wbCtx.moveTo(pos.x, pos.y);
    }
}

function draw(e) {
    if (!isDrawing || !wbCtx) return;
    const pos = getCanvasPos(e);

    if (SHAPE_TOOLS.includes(currentTool)) {
        if (canvasSnapshot) {
            wbCtx.putImageData(canvasSnapshot, 0, 0);
        }
        drawShape(wbCtx, currentTool, startX, startY, pos.x, pos.y, currentColor, currentBrushSize, isShapeFill);
    } else {
        wbCtx.lineTo(pos.x, pos.y);
        wbCtx.lineCap = 'round';
        wbCtx.lineJoin = 'round';

        if (currentTool === 'eraser') {
            wbCtx.strokeStyle = '#ffffff';
            wbCtx.lineWidth = currentBrushSize * 4;
        } else if (currentTool === 'highlighter') {
            wbCtx.strokeStyle = currentColor + '44'; // semi-transparent shading
            wbCtx.lineWidth = currentBrushSize * 3;
        } else {
            wbCtx.strokeStyle = currentColor;
            wbCtx.lineWidth = currentBrushSize;
        }
        wbCtx.stroke();
    }
}

function stopDrawing() {
    if (!isDrawing) return;
    const canvas = document.getElementById('artWhiteboardCanvas');
    if (!canvas || !wbCtx) return;

    if (!SHAPE_TOOLS.includes(currentTool)) {
        wbCtx.closePath();
    }
    isDrawing = false;
    canvasSnapshot = null;
    saveUndoState();
}

function drawShape(ctx, tool, x1, y1, x2, y2, color, lineWidth, isFilled) {
    ctx.save();
    ctx.lineWidth = Math.max(lineWidth, 1);
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    if (tool === 'line') {
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
    } else if (tool === 'curve') {
        const midX = (x1 + x2) / 2;
        const midY = (y1 + y2) / 2;
        const dx = x2 - x1;
        const dy = y2 - y1;
        const dist = Math.hypot(dx, dy);
        // Arched curve control point
        const cpX = midX - (dy / (dist || 1)) * (dist * 0.32);
        const cpY = midY + (dx / (dist || 1)) * (dist * 0.32);
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.quadraticCurveTo(cpX, cpY, x2, y2);
        ctx.stroke();
    } else if (tool === 'square') {
        const side = Math.max(Math.min(Math.abs(x2 - x1), Math.abs(y2 - y1)), 4);
        const rx = x2 >= x1 ? x1 : x1 - side;
        const ry = y2 >= y1 ? y1 : y1 - side;
        ctx.beginPath();
        ctx.rect(rx, ry, side, side);
        if (isFilled) ctx.fill();
        ctx.stroke();
    } else if (tool === 'rectangle') {
        const rx = Math.min(x1, x2);
        const ry = Math.min(y1, y2);
        const rw = Math.max(Math.abs(x2 - x1), 4);
        const rh = Math.max(Math.abs(y2 - y1), 4);
        ctx.beginPath();
        ctx.rect(rx, ry, rw, rh);
        if (isFilled) ctx.fill();
        ctx.stroke();
    } else if (tool === 'circle') {
        const cx = (x1 + x2) / 2;
        const cy = (y1 + y2) / 2;
        const rx = Math.max(Math.abs(x2 - x1) / 2, 2);
        const ry = Math.max(Math.abs(y2 - y1) / 2, 2);
        ctx.beginPath();
        ctx.ellipse(cx, cy, rx, ry, 0, 0, 2 * Math.PI);
        if (isFilled) ctx.fill();
        ctx.stroke();
    } else if (tool === 'triangle') {
        // Pyramid / Triangle
        const topX = (x1 + x2) / 2;
        const topY = Math.min(y1, y2);
        const bottomY = Math.max(y1, y2);
        const leftX = Math.min(x1, x2);
        const rightX = Math.max(x1, x2);
        ctx.beginPath();
        ctx.moveTo(topX, topY);
        ctx.lineTo(leftX, bottomY);
        ctx.lineTo(rightX, bottomY);
        ctx.closePath();
        if (isFilled) ctx.fill();
        ctx.stroke();

        // 3D Pyramid ridge line
        ctx.beginPath();
        ctx.moveTo(topX, topY);
        ctx.lineTo(topX, bottomY);
        ctx.strokeStyle = isFilled ? 'rgba(0,0,0,0.22)' : color;
        ctx.stroke();
    } else if (tool === 'flower') {
        // Multi-Petal Flower Shape
        const cx = (x1 + x2) / 2;
        const cy = (y1 + y2) / 2;
        const radius = Math.max(Math.hypot(x2 - x1, y2 - y1) / 2, 12);
        const petals = 6;
        ctx.beginPath();
        for (let angle = 0; angle <= Math.PI * 2 + 0.05; angle += 0.04) {
            const r = radius * (0.62 + 0.38 * Math.sin(petals * angle));
            const px = cx + r * Math.cos(angle);
            const py = cy + r * Math.sin(angle);
            if (angle === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
        }
        ctx.closePath();
        if (isFilled) ctx.fill();
        ctx.stroke();

        // Center floral carpel circle
        ctx.beginPath();
        ctx.arc(cx, cy, Math.max(radius * 0.22, 4), 0, Math.PI * 2);
        if (isFilled) {
            ctx.fillStyle = '#f59e0b';
            ctx.fill();
            ctx.fillStyle = color;
        }
        ctx.stroke();
    } else if (tool === 'star') {
        const cx = (x1 + x2) / 2;
        const cy = (y1 + y2) / 2;
        const r = Math.max(Math.hypot(x2 - x1, y2 - y1) / 2, 6);
        const spikes = 5;
        const step = Math.PI / spikes;
        let rot = (Math.PI / 2) * 3;
        ctx.beginPath();
        for (let i = 0; i < spikes; i++) {
            let sx = cx + Math.cos(rot) * r;
            let sy = cy + Math.sin(rot) * r;
            if (i === 0) ctx.moveTo(sx, sy);
            else ctx.lineTo(sx, sy);
            rot += step;
            sx = cx + Math.cos(rot) * (r * 0.45);
            sy = cy + Math.sin(rot) * (r * 0.45);
            ctx.lineTo(sx, sy);
            rot += step;
        }
        ctx.closePath();
        if (isFilled) ctx.fill();
        ctx.stroke();
    } else if (tool === 'heart') {
        const hx = (x1 + x2) / 2;
        const hy = Math.min(y1, y2);
        const hw = Math.max(Math.abs(x2 - x1), 10);
        const hh = Math.max(Math.abs(y2 - y1), 10);
        const topCurveHeight = hh * 0.3;
        ctx.beginPath();
        ctx.moveTo(hx, hy + topCurveHeight);
        ctx.bezierCurveTo(hx, hy, hx - hw / 2, hy, hx - hw / 2, hy + topCurveHeight);
        ctx.bezierCurveTo(hx - hw / 2, hy + (hh + topCurveHeight) / 2, hx, hy + hh * 0.8, hx, hy + hh);
        ctx.bezierCurveTo(hx, hy + hh * 0.8, hx + hw / 2, hy + (hh + topCurveHeight) / 2, hx + hw / 2, hy + topCurveHeight);
        ctx.bezierCurveTo(hx + hw / 2, hy, hx, hy, hx, hy + topCurveHeight);
        ctx.closePath();
        if (isFilled) ctx.fill();
        ctx.stroke();
    }

    ctx.restore();
}

function getCanvasPos(e) {
    const canvas = document.getElementById('artWhiteboardCanvas');
    const rect = canvas.getBoundingClientRect();
    return {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
    };
}

// ==========================================
// 5. Guitar Chord Visualizer, Search & Strum Player
// ==========================================
const GUITAR_CHORD_DATA = {
    // === MAJOR CHORDS ===
    'C': {
        name: 'C Major',
        type: 'Open Major Chord',
        notes: 'C - E - G',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 0, finger: 0 },
            { string: 2, fret: 1, finger: 1 },
            { string: 3, fret: 0, finger: 0 },
            { string: 4, fret: 2, finger: 2 },
            { string: 5, fret: 3, finger: 3 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Standard open C Major chord. Keep your thumb centered behind the guitar neck for clean string arching.'
    },
    'D': {
        name: 'D Major',
        type: 'Open Major Chord',
        notes: 'D - F# - A',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 2, finger: 2 },
            { string: 2, fret: 3, finger: 3 },
            { string: 3, fret: 2, finger: 1 },
            { string: 4, fret: 0, finger: 0 },
            { string: 5, fret: 'x', finger: 0 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Bright open D Major. Let the 4th string (open D) ring clearly as the resonant bass root.'
    },
    'E': {
        name: 'E Major',
        type: 'Open Major Chord',
        notes: 'E - G# - B',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 0, finger: 0 },
            { string: 2, fret: 0, finger: 0 },
            { string: 3, fret: 1, finger: 1 },
            { string: 4, fret: 2, finger: 3 },
            { string: 5, fret: 2, finger: 2 },
            { string: 6, fret: 0, finger: 0 }
        ],
        description: 'Powerful 6-string open chord driving rock, blues, and classical Indian acoustic compositions.'
    },
    'F': {
        name: 'F Major',
        type: '1st Fret Barre Chord',
        notes: 'F - A - C',
        baseFret: 1,
        barre: { fret: 1, fromString: 6, toString: 1, finger: 1 },
        fretPositions: [
            { string: 1, fret: 1, finger: 1 },
            { string: 2, fret: 1, finger: 1 },
            { string: 3, fret: 2, finger: 2 },
            { string: 4, fret: 3, finger: 4 },
            { string: 5, fret: 3, finger: 3 },
            { string: 6, fret: 1, finger: 1 }
        ],
        description: 'Full 1st-fret barre chord. Strengthens index finger barring technique across all 6 strings.'
    },
    'G': {
        name: 'G Major',
        type: 'Open Major Chord',
        notes: 'G - B - D',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 3, finger: 4 },
            { string: 2, fret: 0, finger: 0 },
            { string: 3, fret: 0, finger: 0 },
            { string: 4, fret: 0, finger: 0 },
            { string: 5, fret: 2, finger: 1 },
            { string: 6, fret: 3, finger: 2 }
        ],
        description: 'Rich resonant open G Major. All six strings ringing with natural wooden harmonics.'
    },
    'A': {
        name: 'A Major',
        type: 'Open Major Chord',
        notes: 'A - C# - E',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 0, finger: 0 },
            { string: 2, fret: 2, finger: 3 },
            { string: 3, fret: 2, finger: 2 },
            { string: 4, fret: 2, finger: 1 },
            { string: 5, fret: 0, finger: 0 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Open A Major chord. Align fingers 1, 2, and 3 closely inside the 2nd fret.'
    },
    'B': {
        name: 'B Major',
        type: '2nd Fret Barre Chord',
        notes: 'B - D# - F#',
        baseFret: 2,
        barre: { fret: 2, fromString: 5, toString: 1, finger: 1 },
        fretPositions: [
            { string: 1, fret: 2, finger: 1 },
            { string: 2, fret: 4, finger: 4 },
            { string: 3, fret: 4, finger: 3 },
            { string: 4, fret: 4, finger: 2 },
            { string: 5, fret: 2, finger: 1 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Standard 2nd-fret A-shape barre chord. Keep the low 6th string cleanly muted.'
    },
    'Bb': {
        name: 'B-flat Major (Bb / A#)',
        type: '1st Fret Barre Chord',
        notes: 'Bb - D - F',
        baseFret: 1,
        barre: { fret: 1, fromString: 5, toString: 1, finger: 1 },
        fretPositions: [
            { string: 1, fret: 1, finger: 1 },
            { string: 2, fret: 3, finger: 4 },
            { string: 3, fret: 3, finger: 3 },
            { string: 4, fret: 3, finger: 2 },
            { string: 5, fret: 1, finger: 1 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: '1st-fret A-shape barre chord. Frequently used in jazz, devotional, and brass-accompanied pieces.'
    },
    'F#': {
        name: 'F-sharp Major (F# / Gb)',
        type: '2nd Fret Barre Chord',
        notes: 'F# - A# - C#',
        baseFret: 2,
        barre: { fret: 2, fromString: 6, toString: 1, finger: 1 },
        fretPositions: [
            { string: 1, fret: 2, finger: 1 },
            { string: 2, fret: 2, finger: 1 },
            { string: 3, fret: 3, finger: 2 },
            { string: 4, fret: 4, finger: 4 },
            { string: 5, fret: 4, finger: 3 },
            { string: 6, fret: 2, finger: 1 }
        ],
        description: 'Full 2nd-fret barre chord with brilliant harmonic projection.'
    },
    'Eb': {
        name: 'E-flat Major (Eb / D#)',
        type: 'Moveable Major Voicing',
        notes: 'Eb - G - Bb',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 3, finger: 3 },
            { string: 2, fret: 4, finger: 4 },
            { string: 3, fret: 3, finger: 2 },
            { string: 4, fret: 1, finger: 1 },
            { string: 5, fret: 'x', finger: 0 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Compact 4-string Eb Major voicing commonly used in classical acoustic arrangements.'
    },

    // === MINOR CHORDS ===
    'Am': {
        name: 'A Minor',
        type: 'Open Minor Chord',
        notes: 'A - C - E',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 0, finger: 0 },
            { string: 2, fret: 1, finger: 1 },
            { string: 3, fret: 2, finger: 3 },
            { string: 4, fret: 2, finger: 2 },
            { string: 5, fret: 0, finger: 0 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Soulful minor chord frequently used in acoustic ballads and Indian folk melodies.'
    },
    'Bm': {
        name: 'B Minor',
        type: '2nd Fret Minor Barre Chord',
        notes: 'B - D - F#',
        baseFret: 2,
        barre: { fret: 2, fromString: 5, toString: 1, finger: 1 },
        fretPositions: [
            { string: 1, fret: 2, finger: 1 },
            { string: 2, fret: 3, finger: 2 },
            { string: 3, fret: 4, finger: 4 },
            { string: 4, fret: 4, finger: 3 },
            { string: 5, fret: 2, finger: 1 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Essential 2nd-fret barre chord in rock, pop, and acoustic progressions.'
    },
    'Cm': {
        name: 'C Minor',
        type: '3rd Fret Minor Barre Chord',
        notes: 'C - Eb - G',
        baseFret: 3,
        barre: { fret: 3, fromString: 5, toString: 1, finger: 1 },
        fretPositions: [
            { string: 1, fret: 3, finger: 1 },
            { string: 2, fret: 4, finger: 2 },
            { string: 3, fret: 5, finger: 4 },
            { string: 4, fret: 5, finger: 3 },
            { string: 5, fret: 3, finger: 1 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: '3rd-fret barre chord with poignant classical acoustic resonance.'
    },
    'C#m': {
        name: 'C-sharp Minor (C#m / Dbm)',
        type: '4th Fret Minor Barre Chord',
        notes: 'C# - E - G#',
        baseFret: 4,
        barre: { fret: 4, fromString: 5, toString: 1, finger: 1 },
        fretPositions: [
            { string: 1, fret: 4, finger: 1 },
            { string: 2, fret: 5, finger: 2 },
            { string: 3, fret: 6, finger: 4 },
            { string: 4, fret: 6, finger: 3 },
            { string: 5, fret: 4, finger: 1 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: '4th-fret barre chord. Key chord in dramatic and passionate compositions.'
    },
    'Dm': {
        name: 'D Minor',
        type: 'Open Minor Chord',
        notes: 'D - F - A',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 1, finger: 1 },
            { string: 2, fret: 3, finger: 3 },
            { string: 3, fret: 2, finger: 2 },
            { string: 4, fret: 0, finger: 0 },
            { string: 5, fret: 'x', finger: 0 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Melancholic tone used in classical, flamenco, and Spanish acoustic traditions.'
    },
    'Em': {
        name: 'E Minor',
        type: 'Open Minor Chord',
        notes: 'E - G - B',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 0, finger: 0 },
            { string: 2, fret: 0, finger: 0 },
            { string: 3, fret: 0, finger: 0 },
            { string: 4, fret: 2, finger: 2 },
            { string: 5, fret: 2, finger: 1 },
            { string: 6, fret: 0, finger: 0 }
        ],
        description: 'Deep and mellow. One of the foundational chords for every beginning guitarist.'
    },
    'Fm': {
        name: 'F Minor',
        type: '1st Fret Minor Barre Chord',
        notes: 'F - Ab - C',
        baseFret: 1,
        barre: { fret: 1, fromString: 6, toString: 1, finger: 1 },
        fretPositions: [
            { string: 1, fret: 1, finger: 1 },
            { string: 2, fret: 1, finger: 1 },
            { string: 3, fret: 1, finger: 1 },
            { string: 4, fret: 3, finger: 4 },
            { string: 5, fret: 3, finger: 3 },
            { string: 6, fret: 1, finger: 1 }
        ],
        description: 'Full 1st-fret minor barre shape with haunting emotional depth.'
    },
    'F#m': {
        name: 'F-sharp Minor (F#m / Gbm)',
        type: '2nd Fret Minor Barre Chord',
        notes: 'F# - A - C#',
        baseFret: 2,
        barre: { fret: 2, fromString: 6, toString: 1, finger: 1 },
        fretPositions: [
            { string: 1, fret: 2, finger: 1 },
            { string: 2, fret: 2, finger: 1 },
            { string: 3, fret: 2, finger: 1 },
            { string: 4, fret: 4, finger: 4 },
            { string: 5, fret: 4, finger: 3 },
            { string: 6, fret: 2, finger: 1 }
        ],
        description: 'Crucial 2nd-fret minor barre in the keys of A Major and D Major.'
    },
    'Gm': {
        name: 'G Minor',
        type: '3rd Fret Minor Barre Chord',
        notes: 'G - Bb - D',
        baseFret: 3,
        barre: { fret: 3, fromString: 6, toString: 1, finger: 1 },
        fretPositions: [
            { string: 1, fret: 3, finger: 1 },
            { string: 2, fret: 3, finger: 1 },
            { string: 3, fret: 3, finger: 1 },
            { string: 4, fret: 5, finger: 4 },
            { string: 5, fret: 5, finger: 3 },
            { string: 6, fret: 3, finger: 1 }
        ],
        description: '3rd-fret minor barre chord with warm bottom acoustic fullness.'
    },
    'G#m': {
        name: 'G-sharp Minor (G#m / Abm)',
        type: '4th Fret Minor Barre Chord',
        notes: 'G# - B - D#',
        baseFret: 4,
        barre: { fret: 4, fromString: 6, toString: 1, finger: 1 },
        fretPositions: [
            { string: 1, fret: 4, finger: 1 },
            { string: 2, fret: 4, finger: 1 },
            { string: 3, fret: 4, finger: 1 },
            { string: 4, fret: 6, finger: 4 },
            { string: 5, fret: 6, finger: 3 },
            { string: 6, fret: 4, finger: 1 }
        ],
        description: '4th-fret minor barre chord commonly found in soulful acoustics.'
    },
    'Bbm': {
        name: 'B-flat Minor (Bbm / A#m)',
        type: '1st Fret Minor Barre Chord',
        notes: 'Bb - Db - F',
        baseFret: 1,
        barre: { fret: 1, fromString: 5, toString: 1, finger: 1 },
        fretPositions: [
            { string: 1, fret: 1, finger: 1 },
            { string: 2, fret: 2, finger: 2 },
            { string: 3, fret: 3, finger: 4 },
            { string: 4, fret: 3, finger: 3 },
            { string: 5, fret: 1, finger: 1 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: '1st-fret Am-shape minor barre chord.'
    },

    // === DOMINANT 7TH CHORDS ===
    'C7': {
        name: 'C Dominant 7th (C7)',
        type: 'Dominant 7th Chord',
        notes: 'C - E - G - Bb',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 0, finger: 0 },
            { string: 2, fret: 1, finger: 1 },
            { string: 3, fret: 3, finger: 4 },
            { string: 4, fret: 2, finger: 2 },
            { string: 5, fret: 3, finger: 3 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Classic blues turnaround chord leading smoothly into F Major.'
    },
    'D7': {
        name: 'D Dominant 7th (D7)',
        type: 'Dominant 7th Chord',
        notes: 'D - F# - A - C',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 2, finger: 3 },
            { string: 2, fret: 1, finger: 1 },
            { string: 3, fret: 2, finger: 2 },
            { string: 4, fret: 0, finger: 0 },
            { string: 5, fret: 'x', finger: 0 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Inverted triangle open shape with crisp harmonic tension.'
    },
    'E7': {
        name: 'E Dominant 7th (E7)',
        type: 'Dominant 7th Chord',
        notes: 'E - G# - B - D',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 0, finger: 0 },
            { string: 2, fret: 0, finger: 0 },
            { string: 3, fret: 1, finger: 1 },
            { string: 4, fret: 0, finger: 0 },
            { string: 5, fret: 2, finger: 2 },
            { string: 6, fret: 0, finger: 0 }
        ],
        description: 'Open acoustic blues staple with 4 open ringing strings.'
    },
    'F7': {
        name: 'F Dominant 7th (F7)',
        type: 'Dominant 7th Chord',
        notes: 'F - A - C - Eb',
        baseFret: 1,
        barre: { fret: 1, fromString: 6, toString: 1, finger: 1 },
        fretPositions: [
            { string: 1, fret: 1, finger: 1 },
            { string: 2, fret: 1, finger: 1 },
            { string: 3, fret: 2, finger: 2 },
            { string: 4, fret: 1, finger: 1 },
            { string: 5, fret: 3, finger: 3 },
            { string: 6, fret: 1, finger: 1 }
        ],
        description: '1st-fret barre 7th chord with funky blues resolution.'
    },
    'G7': {
        name: 'G Dominant 7th (G7)',
        type: 'Dominant 7th Chord',
        notes: 'G - B - D - F',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 1, finger: 1 },
            { string: 2, fret: 0, finger: 0 },
            { string: 3, fret: 0, finger: 0 },
            { string: 4, fret: 0, finger: 0 },
            { string: 5, fret: 2, finger: 2 },
            { string: 6, fret: 3, finger: 3 }
        ],
        description: 'The quintessential dominant tension chord resolving cleanly back to C Major.'
    },
    'A7': {
        name: 'A Dominant 7th (A7)',
        type: 'Dominant 7th Chord',
        notes: 'A - C# - E - G',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 0, finger: 0 },
            { string: 2, fret: 2, finger: 2 },
            { string: 3, fret: 0, finger: 0 },
            { string: 4, fret: 2, finger: 1 },
            { string: 5, fret: 0, finger: 0 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Two-finger open chord with open 3rd G string ringing in the center.'
    },
    'B7': {
        name: 'B Dominant 7th (B7)',
        type: 'Dominant 7th Chord',
        notes: 'B - D# - F# - A',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 2, finger: 4 },
            { string: 2, fret: 0, finger: 0 },
            { string: 3, fret: 2, finger: 3 },
            { string: 4, fret: 1, finger: 1 },
            { string: 5, fret: 2, finger: 2 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Famous fingerpicking dominant chord resolving into E Minor or E Major.'
    },

    // === MAJOR 7TH CHORDS ===
    'Cmaj7': {
        name: 'C Major 7th (Cmaj7)',
        type: 'Major 7th Chord',
        notes: 'C - E - G - B',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 0, finger: 0 },
            { string: 2, fret: 0, finger: 0 },
            { string: 3, fret: 0, finger: 0 },
            { string: 4, fret: 2, finger: 2 },
            { string: 5, fret: 3, finger: 3 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Lush, dreamy acoustic tone loved in neo-soul, jazz, and contemporary balladry.'
    },
    'Dmaj7': {
        name: 'D Major 7th (Dmaj7)',
        type: 'Major 7th Chord',
        notes: 'D - F# - A - C#',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 2, finger: 3 },
            { string: 2, fret: 2, finger: 2 },
            { string: 3, fret: 2, finger: 1 },
            { string: 4, fret: 0, finger: 0 },
            { string: 5, fret: 'x', finger: 0 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Sweet melodic chord barred across strings 1, 2, and 3 at the 2nd fret.'
    },
    'Emaj7': {
        name: 'E Major 7th (Emaj7)',
        type: 'Major 7th Chord',
        notes: 'E - G# - B - D#',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 0, finger: 0 },
            { string: 2, fret: 0, finger: 0 },
            { string: 3, fret: 1, finger: 1 },
            { string: 4, fret: 1, finger: 2 },
            { string: 5, fret: 2, finger: 3 },
            { string: 6, fret: 0, finger: 0 }
        ],
        description: 'Ethereal, warm harmony anchored by the open low E bass string.'
    },
    'Fmaj7': {
        name: 'F Major 7th (Fmaj7)',
        type: 'Major 7th Chord',
        notes: 'F - A - C - E',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 0, finger: 0 },
            { string: 2, fret: 1, finger: 1 },
            { string: 3, fret: 2, finger: 2 },
            { string: 4, fret: 3, finger: 3 },
            { string: 5, fret: 'x', finger: 0 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Easy beginner-friendly alternative to the full F barre chord with an open 1st E string.'
    },
    'Gmaj7': {
        name: 'G Major 7th (Gmaj7)',
        type: 'Major 7th Chord',
        notes: 'G - B - D - F#',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 2, finger: 1 },
            { string: 2, fret: 0, finger: 0 },
            { string: 3, fret: 0, finger: 0 },
            { string: 4, fret: 0, finger: 0 },
            { string: 5, fret: 2, finger: 2 },
            { string: 6, fret: 3, finger: 3 }
        ],
        description: 'Gentle, floating open chord with the high F# adding sparkling color.'
    },
    'Amaj7': {
        name: 'A Major 7th (Amaj7)',
        type: 'Major 7th Chord',
        notes: 'A - C# - E - G#',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 0, finger: 0 },
            { string: 2, fret: 2, finger: 3 },
            { string: 3, fret: 1, finger: 1 },
            { string: 4, fret: 2, finger: 2 },
            { string: 5, fret: 0, finger: 0 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Velvety, intimate acoustic voicing.'
    },

    // === MINOR 7TH CHORDS ===
    'Am7': {
        name: 'A Minor 7th (Am7)',
        type: 'Minor 7th Chord',
        notes: 'A - C - E - G',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 0, finger: 0 },
            { string: 2, fret: 1, finger: 1 },
            { string: 3, fret: 0, finger: 0 },
            { string: 4, fret: 2, finger: 2 },
            { string: 5, fret: 0, finger: 0 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Smooth folk and acoustic R&B open chord mastered with just two fingers.'
    },
    'Bm7': {
        name: 'B Minor 7th (Bm7)',
        type: '2nd Fret Minor 7th Barre Chord',
        notes: 'B - D - F# - A',
        baseFret: 2,
        barre: { fret: 2, fromString: 5, toString: 1, finger: 1 },
        fretPositions: [
            { string: 1, fret: 2, finger: 1 },
            { string: 2, fret: 3, finger: 2 },
            { string: 3, fret: 2, finger: 1 },
            { string: 4, fret: 4, finger: 3 },
            { string: 5, fret: 2, finger: 1 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Mellow 2nd-fret minor 7th barre with refined harmonic nuance.'
    },
    'Cm7': {
        name: 'C Minor 7th (Cm7)',
        type: '3rd Fret Minor 7th Barre Chord',
        notes: 'C - Eb - G - Bb',
        baseFret: 3,
        barre: { fret: 3, fromString: 5, toString: 1, finger: 1 },
        fretPositions: [
            { string: 1, fret: 3, finger: 1 },
            { string: 2, fret: 4, finger: 2 },
            { string: 3, fret: 3, finger: 1 },
            { string: 4, fret: 5, finger: 3 },
            { string: 5, fret: 3, finger: 1 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: '3rd-fret jazzy minor 7th barre.'
    },
    'Dm7': {
        name: 'D Minor 7th (Dm7)',
        type: 'Minor 7th Chord',
        notes: 'D - F - A - C',
        baseFret: 1,
        barre: { fret: 1, fromString: 2, toString: 1, finger: 1 },
        fretPositions: [
            { string: 1, fret: 1, finger: 1 },
            { string: 2, fret: 1, finger: 1 },
            { string: 3, fret: 2, finger: 2 },
            { string: 4, fret: 0, finger: 0 },
            { string: 5, fret: 'x', finger: 0 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Compact mini-barre with the open 4th D string.'
    },
    'Em7': {
        name: 'E Minor 7th (Em7)',
        type: 'Minor 7th Chord',
        notes: 'E - G - B - D',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 0, finger: 0 },
            { string: 2, fret: 0, finger: 0 },
            { string: 3, fret: 0, finger: 0 },
            { string: 4, fret: 0, finger: 0 },
            { string: 5, fret: 2, finger: 1 },
            { string: 6, fret: 0, finger: 0 }
        ],
        description: 'Effortless one-finger minor 7th chord with 5 open strings ringing.'
    },
    'F#m7': {
        name: 'F-sharp Minor 7th (F#m7)',
        type: '2nd Fret Minor 7th Barre Chord',
        notes: 'F# - A - C# - E',
        baseFret: 2,
        barre: { fret: 2, fromString: 6, toString: 1, finger: 1 },
        fretPositions: [
            { string: 1, fret: 2, finger: 1 },
            { string: 2, fret: 2, finger: 1 },
            { string: 3, fret: 2, finger: 1 },
            { string: 4, fret: 2, finger: 1 },
            { string: 5, fret: 4, finger: 3 },
            { string: 6, fret: 2, finger: 1 }
        ],
        description: 'Sophisticated 2nd-fret full barre minor 7th.'
    },

    // === SUSPENDED & ADD CHORDS ===
    'Dsus4': {
        name: 'D Suspended 4th (Dsus4)',
        type: 'Suspended Chord',
        notes: 'D - G - A',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 3, finger: 4 },
            { string: 2, fret: 3, finger: 3 },
            { string: 3, fret: 2, finger: 1 },
            { string: 4, fret: 0, finger: 0 },
            { string: 5, fret: 'x', finger: 0 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Creates suspension tension that resolves deliciously back to D Major.'
    },
    'Dsus2': {
        name: 'D Suspended 2nd (Dsus2)',
        type: 'Suspended Chord',
        notes: 'D - E - A',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 0, finger: 0 },
            { string: 2, fret: 3, finger: 3 },
            { string: 3, fret: 2, finger: 1 },
            { string: 4, fret: 0, finger: 0 },
            { string: 5, fret: 'x', finger: 0 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Airy, open two-finger D chord with the 1st string ringing open.'
    },
    'Asus4': {
        name: 'A Suspended 4th (Asus4)',
        type: 'Suspended Chord',
        notes: 'A - D - E',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 0, finger: 0 },
            { string: 2, fret: 3, finger: 4 },
            { string: 3, fret: 2, finger: 3 },
            { string: 4, fret: 2, finger: 2 },
            { string: 5, fret: 0, finger: 0 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Anthemic suspense chord resolving into A Major.'
    },
    'Asus2': {
        name: 'A Suspended 2nd (Asus2)',
        type: 'Suspended Chord',
        notes: 'A - B - E',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 0, finger: 0 },
            { string: 2, fret: 0, finger: 0 },
            { string: 3, fret: 2, finger: 2 },
            { string: 4, fret: 2, finger: 1 },
            { string: 5, fret: 0, finger: 0 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Pure, calm acoustic resonance with two open top strings.'
    },
    'Esus4': {
        name: 'E Suspended 4th (Esus4)',
        type: 'Suspended Chord',
        notes: 'E - A - B',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 0, finger: 0 },
            { string: 2, fret: 0, finger: 0 },
            { string: 3, fret: 2, finger: 3 },
            { string: 4, fret: 2, finger: 2 },
            { string: 5, fret: 2, finger: 1 },
            { string: 6, fret: 0, finger: 0 }
        ],
        description: 'Powerful rock and pop suspension resolving to E Major.'
    },
    'Gsus4': {
        name: 'G Suspended 4th (Gsus4)',
        type: 'Suspended Chord',
        notes: 'G - C - D',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 3, finger: 4 },
            { string: 2, fret: 1, finger: 1 },
            { string: 3, fret: 0, finger: 0 },
            { string: 4, fret: 0, finger: 0 },
            { string: 5, fret: 'x', finger: 0 },
            { string: 6, fret: 3, finger: 3 }
        ],
        description: 'Bright open suspension resolving back to G Major.'
    },
    'Cadd9': {
        name: 'C Add 9 (Cadd9)',
        type: 'Add9 Extended Chord',
        notes: 'C - E - G - D',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 3, finger: 4 },
            { string: 2, fret: 3, finger: 3 },
            { string: 3, fret: 0, finger: 0 },
            { string: 4, fret: 2, finger: 1 },
            { string: 5, fret: 3, finger: 2 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'The golden acoustic chord paired famously with G Major and Dsus4.'
    },
    'Csus4': {
        name: 'C Suspended 4th (Csus4)',
        type: 'Suspended Chord',
        notes: 'C - F - G',
        baseFret: 1,
        fretPositions: [
            { string: 1, fret: 1, finger: 1 },
            { string: 2, fret: 1, finger: 1 },
            { string: 3, fret: 0, finger: 0 },
            { string: 4, fret: 3, finger: 4 },
            { string: 5, fret: 3, finger: 3 },
            { string: 6, fret: 'x', finger: 0 }
        ],
        description: 'Lush harmonic suspense resolving to C Major.'
    }
};

// Aliases and query normalization dictionary
const CHORD_ALIASES = {
    'c': 'C', 'cmajor': 'C', 'cmaj': 'C', 'c major': 'C',
    'd': 'D', 'dmajor': 'D', 'dmaj': 'D', 'd major': 'D',
    'e': 'E', 'emajor': 'E', 'emaj': 'E', 'e major': 'E',
    'f': 'F', 'fmajor': 'F', 'fmaj': 'F', 'f major': 'F',
    'g': 'G', 'gmajor': 'G', 'gmaj': 'G', 'g major': 'G',
    'a': 'A', 'amajor': 'A', 'amaj': 'A', 'a major': 'A',
    'b': 'B', 'bmajor': 'B', 'bmaj': 'B', 'b major': 'B',
    'bb': 'Bb', 'b-flat': 'Bb', 'bflat': 'Bb', 'a#': 'Bb', 'asharp': 'Bb', 'a-sharp': 'Bb',
    'f#': 'F#', 'fsharp': 'F#', 'f-sharp': 'F#', 'gb': 'F#', 'gflat': 'F#',
    'eb': 'Eb', 'eflat': 'Eb', 'd#': 'Eb', 'dsharp': 'Eb',

    'am': 'Am', 'aminor': 'Am', 'amin': 'Am', 'a minor': 'Am',
    'bm': 'Bm', 'bminor': 'Bm', 'bmin': 'Bm', 'b minor': 'Bm',
    'cm': 'Cm', 'cminor': 'Cm', 'cmin': 'Cm', 'c minor': 'Cm',
    'c#m': 'C#m', 'csharpm': 'C#m', 'csharpminor': 'C#m', 'c# minor': 'C#m', 'dbm': 'C#m',
    'dm': 'Dm', 'dminor': 'Dm', 'dmin': 'Dm', 'd minor': 'Dm',
    'em': 'Em', 'eminor': 'Em', 'emin': 'Em', 'e minor': 'Em',
    'fm': 'Fm', 'fminor': 'Fm', 'fmin': 'Fm', 'f minor': 'Fm',
    'f#m': 'F#m', 'fsharpm': 'F#m', 'fsharpminor': 'F#m', 'f# minor': 'F#m', 'gbm': 'F#m',
    'gm': 'Gm', 'gminor': 'Gm', 'gmin': 'Gm', 'g minor': 'Gm',
    'g#m': 'G#m', 'gsharpm': 'G#m', 'gsharpminor': 'G#m', 'abm': 'G#m',
    'bbm': 'Bbm', 'bflatm': 'Bbm', 'bflatminor': 'Bbm', 'a#m': 'Bbm',

    'c7': 'C7', 'c 7': 'C7', 'cdominant7': 'C7',
    'd7': 'D7', 'd 7': 'D7', 'ddominant7': 'D7',
    'e7': 'E7', 'e 7': 'E7', 'edominant7': 'E7',
    'f7': 'F7', 'f 7': 'F7', 'fdominant7': 'F7',
    'g7': 'G7', 'g 7': 'G7', 'gdominant7': 'G7',
    'a7': 'A7', 'a 7': 'A7', 'adominant7': 'A7',
    'b7': 'B7', 'b 7': 'B7', 'bdominant7': 'B7',

    'cmaj7': 'Cmaj7', 'c major 7': 'Cmaj7', 'c major 7th': 'Cmaj7', 'cma7': 'Cmaj7', 'c7m': 'Cmaj7',
    'dmaj7': 'Dmaj7', 'd major 7': 'Dmaj7', 'dma7': 'Dmaj7',
    'emaj7': 'Emaj7', 'e major 7': 'Emaj7', 'ema7': 'Emaj7',
    'fmaj7': 'Fmaj7', 'f major 7': 'Fmaj7', 'fma7': 'Fmaj7',
    'gmaj7': 'Gmaj7', 'g major 7': 'Gmaj7', 'gma7': 'Gmaj7',
    'amaj7': 'Amaj7', 'a major 7': 'Amaj7', 'ama7': 'Amaj7',

    'am7': 'Am7', 'a minor 7': 'Am7', 'a min 7': 'Am7',
    'bm7': 'Bm7', 'b minor 7': 'Bm7', 'b min 7': 'Bm7',
    'cm7': 'Cm7', 'c minor 7': 'Cm7', 'c min 7': 'Cm7',
    'dm7': 'Dm7', 'd minor 7': 'Dm7', 'd min 7': 'Dm7',
    'em7': 'Em7', 'e minor 7': 'Em7', 'e min 7': 'Em7',
    'f#m7': 'F#m7', 'fsharpminor7': 'F#m7', 'f# min 7': 'F#m7',

    'dsus4': 'Dsus4', 'd sus 4': 'Dsus4', 'dsus': 'Dsus4',
    'dsus2': 'Dsus2', 'd sus 2': 'Dsus2',
    'asus4': 'Asus4', 'a sus 4': 'Asus4', 'asus': 'Asus4',
    'asus2': 'Asus2', 'a sus 2': 'Asus2',
    'esus4': 'Esus4', 'e sus 4': 'Esus4', 'esus': 'Esus4',
    'gsus4': 'Gsus4', 'g sus 4': 'Gsus4', 'gsus': 'Gsus4',
    'cadd9': 'Cadd9', 'c add 9': 'Cadd9',
    'csus4': 'Csus4', 'c sus 4': 'Csus4', 'csus': 'Csus4'
};

let selectedChordKey = 'C';

function initGuitarVisualizer() {
    // 1. Populate Datalist Autocomplete
    const datalist = document.getElementById('chordAutocompleteList');
    if (datalist) {
        datalist.innerHTML = '';
        Object.keys(GUITAR_CHORD_DATA).forEach(key => {
            const chord = GUITAR_CHORD_DATA[key];
            const opt = document.createElement('option');
            opt.value = key;
            opt.label = `${chord.name} (${chord.notes})`;
            datalist.appendChild(opt);
        });
    }

    // 2. Chip selectors
    const chips = document.querySelectorAll('.chord-chip');
    chips.forEach(chip => {
        chip.addEventListener('click', () => {
            const chordKey = chip.getAttribute('data-chord');
            const input = document.getElementById('typeChordInput');
            if (input) input.value = chordKey;
            lookupAndRenderChord(chordKey, false);
        });
    });

    // 3. Search input & button
    const searchInput = document.getElementById('typeChordInput');
    const searchBtn = document.getElementById('searchChordBtn');
    const clearBtn = document.getElementById('clearChordInputBtn');

    if (searchInput) {
        // Live search on typing
        searchInput.addEventListener('input', () => {
            const val = searchInput.value.trim();
            if (clearBtn) clearBtn.style.display = val.length > 0 ? 'block' : 'none';
            if (val.length > 0) {
                lookupAndRenderChord(val, true);
            }
        });

        // Trigger on Enter
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                lookupAndRenderChord(searchInput.value.trim(), false);
            }
        });
    }

    if (searchBtn) {
        searchBtn.addEventListener('click', () => {
            const val = searchInput ? searchInput.value.trim() : '';
            lookupAndRenderChord(val || selectedChordKey, false);
        });
    }

    if (clearBtn && searchInput) {
        clearBtn.addEventListener('click', () => {
            searchInput.value = '';
            clearBtn.style.display = 'none';
            searchInput.focus();
        });
    }

    // 4. Download chord image buttons
    const downloadBtn = document.getElementById('downloadChordImgBtn');
    if (downloadBtn) {
        downloadBtn.addEventListener('click', () => {
            downloadChordImage(selectedChordKey);
        });
    }

    const cardDownloadBtn = document.getElementById('downloadChordImgCardBtn');
    if (cardDownloadBtn) {
        cardDownloadBtn.addEventListener('click', () => {
            downloadChordImage(selectedChordKey);
        });
    }

    // 5. Sound of Chord Shown in Image Buttons
    const cardPlayBtn = document.getElementById('cardPlayChordSoundBtn');
    if (cardPlayBtn) {
        cardPlayBtn.addEventListener('click', () => {
            if (window.soundEngine) {
                window.soundEngine.strumGuitarChord(selectedChordKey, 'down', 0.032);
            }
        });
    }

    const cardArpeggioBtn = document.getElementById('cardArpeggioChordBtn');
    if (cardArpeggioBtn) {
        cardArpeggioBtn.addEventListener('click', () => {
            if (window.soundEngine) {
                window.soundEngine.pluckArpeggio(selectedChordKey, 0.16);
            }
        });
    }

    // 6. Strum Audio Button
    const strumBtn = document.getElementById('strumChordBtn');
    if (strumBtn) {
        strumBtn.addEventListener('click', () => {
            if (window.soundEngine) {
                window.soundEngine.strumGuitarChord(selectedChordKey);
            }
        });
    }

    // 7. Initialize Strumming Pattern Studio & Rhythm Beat Box
    initStrummingStudio();
    initBeatBox();

    // Initial render
    lookupAndRenderChord('C', false);
}

// ==========================================
// 5B. Guitar Strumming Studio (Custom Typed Patterns)
// ==========================================
let currentStrumStrokes = [];
let isStrumLooping = false;

function initStrummingStudio() {
    const input = document.getElementById('customStrumPatternInput');
    const playBtn = document.getElementById('playStrumPatternBtn');
    const loopBtn = document.getElementById('loopStrumPatternBtn');
    const stopBtn = document.getElementById('stopStrumPatternBtn');
    const tempoSlider = document.getElementById('strumTempoSlider');
    const tempoDisplay = document.getElementById('strumTempoDisplay');
    const presetBtns = document.querySelectorAll('.strum-preset-btn');

    // Parse and render initial pattern
    if (input) {
        currentStrumStrokes = parseStrumPattern(input.value);
        renderStrumStrokeTrack(currentStrumStrokes);

        // Real-time typing update
        input.addEventListener('input', () => {
            currentStrumStrokes = parseStrumPattern(input.value);
            renderStrumStrokeTrack(currentStrumStrokes);
        });

        input.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                playStrumPattern(false);
            }
        });
    }

    // Preset chips
    presetBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            presetBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            const pattern = btn.getAttribute('data-pattern');
            if (input) input.value = pattern;
            currentStrumStrokes = parseStrumPattern(pattern);
            renderStrumStrokeTrack(currentStrumStrokes);
        });
    });

    // Tempo slider
    if (tempoSlider && tempoDisplay) {
        tempoSlider.addEventListener('input', () => {
            tempoDisplay.textContent = `${tempoSlider.value} BPM`;
        });
    }

    // Play once
    if (playBtn) {
        playBtn.addEventListener('click', () => {
            playStrumPattern(false);
        });
    }

    // Loop
    if (loopBtn) {
        loopBtn.addEventListener('click', () => {
            playStrumPattern(true);
        });
    }

    // Stop
    if (stopBtn) {
        stopBtn.addEventListener('click', () => {
            stopStrumPattern();
        });
    }
}

function parseStrumPattern(patternStr) {
    if (!patternStr) return [];
    const trimmed = patternStr.trim();
    const strokes = [];
    const hasExplicitRest = /[-_.]/.test(trimmed);

    for (let i = 0; i < trimmed.length; i++) {
        const char = trimmed[i];
        if (char === 'D' || char === 'd' || char === '↓') {
            strokes.push({ type: 'down', label: 'D', arrow: '↓' });
        } else if (char === 'U' || char === 'u' || char === '↑') {
            strokes.push({ type: 'up', label: 'U', arrow: '↑' });
        } else if (char === '-' || char === '.' || char === '_') {
            strokes.push({ type: 'rest', label: '—', arrow: '•' });
        } else if (char === ' ') {
            if (!hasExplicitRest) {
                if (strokes.length > 0 && strokes[strokes.length - 1].type !== 'rest') {
                    strokes.push({ type: 'rest', label: '—', arrow: '•' });
                }
            }
        }
    }

    return strokes;
}

function renderStrumStrokeTrack(strokes) {
    const track = document.getElementById('strumStrokeLiveTrack');
    if (!track) return;
    track.innerHTML = '';

    strokes.forEach((s, idx) => {
        const pill = document.createElement('div');
        pill.className = `strum-stroke-pill ${s.type}`;
        pill.id = `strumPill_${idx}`;
        pill.innerHTML = `
            <span style="font-size: 1.1rem; line-height: 1;">${s.arrow}</span>
            <span style="font-size: 0.72rem; font-weight: 800;">${s.label}</span>
        `;
        track.appendChild(pill);
    });
}

function playStrumPattern(isLoop = false) {
    if (!window.soundEngine) return;

    const input = document.getElementById('customStrumPatternInput');
    const tempoSlider = document.getElementById('strumTempoSlider');
    const playBtn = document.getElementById('playStrumPatternBtn');
    const loopBtn = document.getElementById('loopStrumPatternBtn');
    const stopBtn = document.getElementById('stopStrumPatternBtn');
    const feedback = document.getElementById('strumPlayingFeedback');

    const bpm = tempoSlider ? parseInt(tempoSlider.value, 10) : 95;
    const strokes = parseStrumPattern(input ? input.value : 'D - D U - U D U');

    if (strokes.length === 0) return;

    isStrumLooping = isLoop;
    if (playBtn) playBtn.style.display = 'none';
    if (loopBtn) loopBtn.style.display = 'none';
    if (stopBtn) stopBtn.style.display = 'inline-flex';

    if (feedback) {
        feedback.innerHTML = isLoop 
            ? `🔁 Looping strumming pattern for <strong>${selectedChordKey}</strong> chord (${bpm} BPM)...` 
            : `▶ Playing strumming pattern for <strong>${selectedChordKey}</strong> chord (${bpm} BPM)...`;
    }

    window.soundEngine.playStrumPattern(
        selectedChordKey,
        strokes,
        bpm,
        isLoop,
        (stroke, strokeIdx) => {
            // Highlight stroke pill
            document.querySelectorAll('.strum-stroke-pill').forEach(p => p.classList.remove('active'));
            const currentPill = document.getElementById(`strumPill_${strokeIdx}`);
            if (currentPill) {
                currentPill.classList.add('active');
            }
        },
        () => {
            stopStrumPattern();
        }
    );
}

function stopStrumPattern() {
    if (window.soundEngine) {
        window.soundEngine.stopStrumPattern();
    }

    const playBtn = document.getElementById('playStrumPatternBtn');
    const loopBtn = document.getElementById('loopStrumPatternBtn');
    const stopBtn = document.getElementById('stopStrumPatternBtn');
    const feedback = document.getElementById('strumPlayingFeedback');

    if (playBtn) playBtn.style.display = 'inline-flex';
    if (loopBtn) loopBtn.style.display = 'inline-flex';
    if (stopBtn) stopBtn.style.display = 'none';
    if (feedback) feedback.textContent = '';

    document.querySelectorAll('.strum-stroke-pill').forEach(p => p.classList.remove('active'));
}

// ==========================================
// 5C. Acoustic Rhythm Beat Box Machine
// ==========================================
function initBeatBox() {
    const startBtn = document.getElementById('startBeatBoxBtn');
    const stopBtn = document.getElementById('stopBeatBoxBtn');
    const grooveSelect = document.getElementById('beatBoxGrooveSelect');
    const tempoSlider = document.getElementById('beatBoxTempoSlider');
    const tempoDisplay = document.getElementById('beatBoxTempoDisplay');
    const jamBtn = document.getElementById('jamTogetherBtn');

    if (tempoSlider && tempoDisplay) {
        tempoSlider.addEventListener('input', () => {
            tempoDisplay.textContent = `${tempoSlider.value} BPM`;
            if (window.soundEngine && window.soundEngine.isBeatBoxRunning) {
                startBeatBox();
            }
        });
    }

    if (grooveSelect) {
        grooveSelect.addEventListener('change', () => {
            if (window.soundEngine && window.soundEngine.isBeatBoxRunning) {
                startBeatBox();
            }
        });
    }

    if (startBtn) {
        startBtn.addEventListener('click', () => {
            startBeatBox();
        });
    }

    if (stopBtn) {
        stopBtn.addEventListener('click', () => {
            stopBeatBox();
        });
    }

    // Jam Together: Strumming + Beat Box simultaneously!
    if (jamBtn) {
        jamBtn.addEventListener('click', () => {
            startBeatBox();
            playStrumPattern(true);
        });
    }
}

function startBeatBox() {
    if (!window.soundEngine) return;

    const grooveSelect = document.getElementById('beatBoxGrooveSelect');
    const tempoSlider = document.getElementById('beatBoxTempoSlider');
    const startBtn = document.getElementById('startBeatBoxBtn');
    const stopBtn = document.getElementById('stopBeatBoxBtn');

    const pattern = grooveSelect ? grooveSelect.value : 'folk4';
    const bpm = tempoSlider ? parseInt(tempoSlider.value, 10) : 95;

    if (startBtn) startBtn.style.display = 'none';
    if (stopBtn) stopBtn.style.display = 'inline-flex';

    window.soundEngine.startBeatBox(pattern, bpm, (beatIndex, totalBeats) => {
        for (let b = 1; b <= 4; b++) {
            const led = document.getElementById(`beatLed_${b}`);
            if (led) {
                if (b === (beatIndex + 1)) {
                    led.classList.add('active');
                } else {
                    led.classList.remove('active');
                }
            }
        }
    });
}

function stopBeatBox() {
    if (window.soundEngine) {
        window.soundEngine.stopBeatBox();
    }

    const startBtn = document.getElementById('startBeatBoxBtn');
    const stopBtn = document.getElementById('stopBeatBoxBtn');

    if (startBtn) startBtn.style.display = 'inline-flex';
    if (stopBtn) stopBtn.style.display = 'none';

    for (let b = 1; b <= 4; b++) {
        const led = document.getElementById(`beatLed_${b}`);
        if (led) led.classList.remove('active');
    }
}

// Smart lookup function
function lookupAndRenderChord(query, isLiveTyping = false) {
    if (!query) return;

    const trimmed = query.trim();
    const rawLower = trimmed.toLowerCase();
    const cleanLower = rawLower.replace(/\s+/g, '').replace(/-/g, '');

    let foundKey = null;

    // Direct exact match
    if (GUITAR_CHORD_DATA[trimmed]) {
        foundKey = trimmed;
    }
    // Alias lookup
    else if (CHORD_ALIASES[rawLower]) {
        foundKey = CHORD_ALIASES[rawLower];
    }
    else if (CHORD_ALIASES[cleanLower]) {
        foundKey = CHORD_ALIASES[cleanLower];
    }
    // Case-insensitive match on dictionary keys
    else {
        const directKey = Object.keys(GUITAR_CHORD_DATA).find(
            k => k.toLowerCase() === rawLower || k.toLowerCase() === cleanLower
        );
        if (directKey) {
            foundKey = directKey;
        } else {
            // Partial name match (e.g., "b minor", "f sharp")
            const nameMatch = Object.keys(GUITAR_CHORD_DATA).find(k => {
                const c = GUITAR_CHORD_DATA[k];
                return c.name.toLowerCase().includes(rawLower) || rawLower.includes(c.name.toLowerCase());
            });
            if (nameMatch) {
                foundKey = nameMatch;
            }
        }
    }

    const statusEl = document.getElementById('chordSearchStatus');

    if (foundKey && GUITAR_CHORD_DATA[foundKey]) {
        selectedChordKey = foundKey;
        renderGuitarFretboard(foundKey);

        // Update active chip state
        const chips = document.querySelectorAll('.chord-chip');
        chips.forEach(chip => {
            if (chip.getAttribute('data-chord') === foundKey) {
                chip.classList.add('active');
            } else {
                chip.classList.remove('active');
            }
        });

        if (statusEl) {
            statusEl.className = 'chord-search-feedback success';
            statusEl.innerHTML = `✓ Found <strong>${GUITAR_CHORD_DATA[foundKey].name}</strong> (${GUITAR_CHORD_DATA[foundKey].notes}) — Ready to view, strum, or download image!`;
        }
    } else {
        if (!isLiveTyping && statusEl) {
            statusEl.className = 'chord-search-feedback warning';
            statusEl.innerHTML = `Chord "<strong>${escapeHTML(trimmed)}</strong>" not recognized. Try: <em>C, Dm, Bm, G7, Cmaj7, F#m, Dsus4, Bb, etc.</em>`;
        }
    }
}

function renderGuitarFretboard(chordKey) {
    const chord = GUITAR_CHORD_DATA[chordKey] || GUITAR_CHORD_DATA['C'];
    const chordNameEl = document.getElementById('guitarChordName');
    const chordNotesEl = document.getElementById('guitarChordNotes');
    const chordDescEl = document.getElementById('guitarChordDesc');
    const chordBadgeEl = document.getElementById('guitarChordTypeBadge');
    const svgWrap = document.getElementById('guitarFretboardSvgWrap');

    if (chordNameEl) chordNameEl.textContent = chord.name;
    if (chordNotesEl) chordNotesEl.textContent = `Notes Formula: ${chord.notes}`;
    if (chordDescEl) chordDescEl.textContent = chord.description;
    if (chordBadgeEl) chordBadgeEl.textContent = chord.type || 'Guitar Chord';

    if (!svgWrap) return;

    // Build High-Quality SVG Fretboard with Nut & Barre support
    const width = 260;
    const height = 300;
    const startX = 48;
    const startY = 56;
    const stringGap = 32;
    const fretGap = 42;
    const numFrets = 5;
    const baseFret = chord.baseFret || 1;

    let svg = `<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg" id="activeFretboardSvg">`;

    // Rounded background card
    svg += `<rect width="${width}" height="${height}" fill="#fdf5f7" rx="14" />`;

    // Nut (thick line at fret 0) or baseFret indicator
    if (baseFret === 1) {
        svg += `<rect x="${startX - 2}" y="${startY - 4}" width="${stringGap * 5 + 4}" height="8" fill="#4a0d17" rx="3" />`;
    } else {
        // Upper fret line
        svg += `<line x1="${startX}" y1="${startY}" x2="${startX + stringGap * 5}" y2="${startY}" stroke="#786c64" stroke-width="3" stroke-linecap="round" />`;
        // Position indicator (e.g. "2fr", "3fr")
        svg += `<text x="${startX - 14}" y="${startY + 27}" text-anchor="end" font-size="13" font-weight="800" font-family="sans-serif" fill="#7b1a2c">${baseFret}fr</text>`;
    }

    // Frets (horizontal lines)
    for (let f = 1; f <= numFrets; f++) {
        const y = startY + f * fretGap;
        svg += `<line x1="${startX}" y1="${y}" x2="${startX + stringGap * 5}" y2="${y}" stroke="#b8a798" stroke-width="2" />`;
    }

    // Strings (vertical lines: string 6 on left, string 1 on right)
    for (let s = 0; s < 6; s++) {
        const x = startX + s * stringGap;
        const thickness = 1.2 + (5 - s) * 0.45; // bass strings are thicker
        svg += `<line x1="${x}" y1="${startY}" x2="${x}" y2="${startY + numFrets * fretGap}" stroke="#786c64" stroke-width="${thickness}" />`;
    }

    // Barre shape overlay if chord specifies barre
    if (chord.barre) {
        const barreRelFret = chord.barre.fret - baseFret + 1;
        if (barreRelFret >= 1 && barreRelFret <= numFrets) {
            const y = startY + (barreRelFret - 0.5) * fretGap;
            const x1 = startX + (6 - chord.barre.fromString) * stringGap;
            const x2 = startX + (6 - chord.barre.toString) * stringGap;
            const minX = Math.min(x1, x2);
            const maxX = Math.max(x1, x2);
            svg += `<rect x="${minX - 11}" y="${y - 11}" width="${(maxX - minX) + 22}" height="22" rx="11" fill="#7b1a2c" stroke="#d4af37" stroke-width="2" opacity="0.95" />`;
            svg += `<text x="${(minX + maxX) / 2}" y="${y + 4}" text-anchor="middle" font-size="11" font-weight="bold" font-family="sans-serif" fill="#ffffff">${chord.barre.finger || 1}</text>`;
        }
    }

    // Draw finger placements or open/mute symbols
    chord.fretPositions.forEach(pos => {
        // string 1 (high E) is rightmost (sIndex = 5), string 6 (low E) is leftmost (sIndex = 0)
        const sIndex = 6 - pos.string;
        const x = startX + sIndex * stringGap;

        if (pos.fret === 'x') {
            // Mute cross
            svg += `<text x="${x}" y="${startY - 14}" text-anchor="middle" font-size="16" font-weight="900" font-family="sans-serif" fill="#dc2626">✕</text>`;
        } else if (pos.fret === 0) {
            // Open string circle
            svg += `<circle cx="${x}" cy="${startY - 18}" r="6.5" fill="#fdf5f7" stroke="#15803d" stroke-width="2.5" />`;
        } else {
            // Finger pressed on fret
            const relFret = pos.fret - baseFret + 1;
            if (relFret >= 1 && relFret <= numFrets) {
                const y = startY + (relFret - 0.5) * fretGap;
                svg += `<circle cx="${x}" cy="${y}" r="11" fill="#7b1a2c" stroke="#d4af37" stroke-width="2" />`;
                svg += `<text x="${x}" y="${y + 4}" text-anchor="middle" font-size="11" font-weight="bold" font-family="sans-serif" fill="#ffffff">${pos.finger}</text>`;
            }
        }
    });

    // String name labels below
    const stringNames = ['E', 'A', 'D', 'G', 'B', 'e'];
    for (let s = 0; s < 6; s++) {
        const x = startX + s * stringGap;
        svg += `<text x="${x}" y="${startY + numFrets * fretGap + 18}" text-anchor="middle" font-size="11" font-weight="700" font-family="sans-serif" fill="#8a7a6e">${stringNames[s]}</text>`;
    }

    svg += `</svg>`;
    svgWrap.innerHTML = svg;
}

// Download Chord Diagram as a High-Resolution PNG Image
function downloadChordImage(chordKey) {
    const key = chordKey || selectedChordKey || 'C';
    const chord = GUITAR_CHORD_DATA[key] || GUITAR_CHORD_DATA['C'];

    // Create high-resolution offscreen canvas (640 x 780)
    const canvas = document.createElement('canvas');
    canvas.width = 640;
    canvas.height = 780;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // 1. Fill luxury background
    const bgGrad = ctx.createLinearGradient(0, 0, 0, canvas.height);
    bgGrad.addColorStop(0, '#fdfbf7');
    bgGrad.addColorStop(1, '#f6ede0');
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Decorative frame borders
    ctx.lineWidth = 4;
    ctx.strokeStyle = '#5c1322'; // Maroon
    ctx.strokeRect(12, 12, canvas.width - 24, canvas.height - 24);

    ctx.lineWidth = 1.5;
    ctx.strokeStyle = '#d4af37'; // Gold
    ctx.strokeRect(18, 18, canvas.width - 36, canvas.height - 36);

    // 2. Academy Header
    ctx.textAlign = 'center';
    ctx.fillStyle = '#5c1322';
    ctx.font = 'bold 22px Georgia, serif';
    ctx.fillText('SAPTAVEENA ACADEMY', canvas.width / 2, 54);

    ctx.fillStyle = '#8a6d3b';
    ctx.font = '13px sans-serif';
    ctx.fillText('Music & Arts Institute • Guitar Discipline • Online & Offline Classes', canvas.width / 2, 76);

    // Divider line
    ctx.strokeStyle = '#e0d5c1';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(40, 92);
    ctx.lineTo(canvas.width - 40, 92);
    ctx.stroke();

    // 3. Chord Title & Notes Formula
    ctx.fillStyle = '#4a0d17';
    ctx.font = 'bold 30px Georgia, serif';
    ctx.fillText(chord.name, canvas.width / 2, 134);

    ctx.fillStyle = '#b45309';
    ctx.font = 'bold 15px sans-serif';
    ctx.fillText(`Notes Formula: ${chord.notes}`, canvas.width / 2, 160);

    // 4. Draw Fretboard on Canvas
    const fretboardX = 200;
    const fretboardY = 224;
    const stringGap = 48;
    const fretGap = 64;
    const numFrets = 5;
    const baseFret = chord.baseFret || 1;

    // Nut / Base Fret
    if (baseFret === 1) {
        ctx.fillStyle = '#4a0d17';
        ctx.fillRect(fretboardX - 4, fretboardY - 6, stringGap * 5 + 8, 10);
    } else {
        ctx.strokeStyle = '#786c64';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(fretboardX, fretboardY);
        ctx.lineTo(fretboardX + stringGap * 5, fretboardY);
        ctx.stroke();

        ctx.fillStyle = '#7b1a2c';
        ctx.font = 'bold 20px sans-serif';
        ctx.textAlign = 'right';
        ctx.fillText(`${baseFret}fr`, fretboardX - 16, fretboardY + 38);
        ctx.textAlign = 'center';
    }

    // Frets
    ctx.strokeStyle = '#b8a798';
    ctx.lineWidth = 2.5;
    for (let f = 1; f <= numFrets; f++) {
        const y = fretboardY + f * fretGap;
        ctx.beginPath();
        ctx.moveTo(fretboardX, y);
        ctx.lineTo(fretboardX + stringGap * 5, y);
        ctx.stroke();
    }

    // Strings
    for (let s = 0; s < 6; s++) {
        const x = fretboardX + s * stringGap;
        ctx.strokeStyle = '#786c64';
        ctx.lineWidth = 1.5 + (5 - s) * 0.55;
        ctx.beginPath();
        ctx.moveTo(x, fretboardY);
        ctx.lineTo(x, fretboardY + numFrets * fretGap);
        ctx.stroke();

        // String name labels below
        const stringNames = ['E', 'A', 'D', 'G', 'B', 'e'];
        ctx.fillStyle = '#8a7a6e';
        ctx.font = 'bold 14px sans-serif';
        ctx.fillText(stringNames[s], x, fretboardY + numFrets * fretGap + 26);
    }

    // Barre Overlay
    if (chord.barre) {
        const barreRelFret = chord.barre.fret - baseFret + 1;
        if (barreRelFret >= 1 && barreRelFret <= numFrets) {
            const y = fretboardY + (barreRelFret - 0.5) * fretGap;
            const x1 = fretboardX + (6 - chord.barre.fromString) * stringGap;
            const x2 = fretboardX + (6 - chord.barre.toString) * stringGap;
            const minX = Math.min(x1, x2);
            const maxX = Math.max(x1, x2);

            ctx.fillStyle = '#7b1a2c';
            ctx.beginPath();
            ctx.roundRect(minX - 15, y - 15, (maxX - minX) + 30, 30, 15);
            ctx.fill();
            ctx.strokeStyle = '#d4af37';
            ctx.lineWidth = 2.5;
            ctx.stroke();

            ctx.fillStyle = '#ffffff';
            ctx.font = 'bold 14px sans-serif';
            ctx.fillText(String(chord.barre.finger || 1), (minX + maxX) / 2, y + 5);
        }
    }

    // Finger Placements
    chord.fretPositions.forEach(pos => {
        const sIndex = 6 - pos.string;
        const x = fretboardX + sIndex * stringGap;

        if (pos.fret === 'x') {
            ctx.fillStyle = '#dc2626';
            ctx.font = 'bold 22px sans-serif';
            ctx.fillText('✕', x, fretboardY - 18);
        } else if (pos.fret === 0) {
            ctx.strokeStyle = '#15803d';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.arc(x, fretboardY - 24, 9, 0, Math.PI * 2);
            ctx.stroke();
        } else {
            const relFret = pos.fret - baseFret + 1;
            if (relFret >= 1 && relFret <= numFrets) {
                const y = fretboardY + (relFret - 0.5) * fretGap;

                ctx.fillStyle = '#7b1a2c';
                ctx.beginPath();
                ctx.arc(x, y, 16, 0, Math.PI * 2);
                ctx.fill();

                ctx.strokeStyle = '#d4af37';
                ctx.lineWidth = 2.5;
                ctx.stroke();

                ctx.fillStyle = '#ffffff';
                ctx.font = 'bold 15px sans-serif';
                ctx.fillText(String(pos.finger), x, y + 5);
            }
        }
    });

    // 5. Rhythm & Notes Footer
    ctx.textAlign = 'center';
    ctx.fillStyle = '#5c1322';
    ctx.font = 'bold 14px sans-serif';
    ctx.fillText('Recommended Rhythm: ↓ - ↓ ↑ - ↑ ↓ ↑ (4/4 Beat)', canvas.width / 2, 630);

    ctx.fillStyle = '#555';
    ctx.font = 'italic 12px sans-serif';
    ctx.fillText(chord.description, canvas.width / 2, 654);

    // Watermark & Mentorship
    ctx.strokeStyle = '#e0d5c1';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(50, 680);
    ctx.lineTo(canvas.width - 50, 680);
    ctx.stroke();

    ctx.fillStyle = '#7b1a2c';
    ctx.font = 'bold 13px Georgia, serif';
    ctx.fillText('Saptaveena Academy • Chief Academic Mentor: Sushmita Saha', canvas.width / 2, 706);
    ctx.fillStyle = '#8a7a6e';
    ctx.font = '11px sans-serif';
    ctx.fillText('Authorized Student Study Material • Learn, Create, Perform', canvas.width / 2, 724);

    // Download Trigger
    const safeName = key.replace(/#/g, 'sharp').toLowerCase();
    const link = document.createElement('a');
    link.download = `saptaveena-guitar-chord-${safeName}.png`;
    link.href = canvas.toDataURL('image/png');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    // Update status
    const statusEl = document.getElementById('chordSearchStatus');
    if (statusEl) {
        statusEl.className = 'chord-search-feedback success';
        statusEl.innerHTML = `✓ Successfully saved image: <strong>saptaveena-guitar-chord-${safeName}.png</strong>!`;
    }
}

// ==========================================
// 6. Harmonium Swar Keyboard & Classical Ragas Player
// ==========================================
const HARMONIUM_KEYS = [
    { swar: 'Sa', western: 'C4', freq: 261.63, isBlack: false },
    { swar: 're', western: 'C#4', freq: 277.18, isBlack: true, leftPercent: 5.2 },
    { swar: 'Re', western: 'D4', freq: 293.66, isBlack: false },
    { swar: 'ga', western: 'D#4', freq: 311.13, isBlack: true, leftPercent: 17.6 },
    { swar: 'Ga', western: 'E4', freq: 329.63, isBlack: false },
    { swar: 'Ma', western: 'F4', freq: 349.23, isBlack: false },
    { swar: 'M\'', western: 'F#4', freq: 369.99, isBlack: true, leftPercent: 42.4 },
    { swar: 'Pa', western: 'G4', freq: 392.00, isBlack: false },
    { swar: 'dha', western: 'G#4', freq: 415.30, isBlack: true, leftPercent: 54.8 },
    { swar: 'Dha', western: 'A4', freq: 440.00, isBlack: false },
    { swar: 'ni', western: 'A#4', freq: 466.16, isBlack: true, leftPercent: 67.2 },
    { swar: 'Ni', western: 'B4', freq: 493.88, isBlack: false },
    { swar: 'Ṡa', western: 'C5', freq: 523.25, isBlack: false }
];

const INDIAN_RAGA_DATA = {
    'yaman': {
        name: 'Raga Yaman (Kalyan)',
        thaat: 'Kalyan',
        prahar: 'Evening (1st Prahar of Night)',
        vadi: 'Ga',
        samvadi: 'Ni',
        aarohNotes: ['Ni', 'Re', 'Ga', 'M\'', 'Dha', 'Ni', 'Ṡa'],
        avrohNotes: ['Ṡa', 'Ni', 'Dha', 'Pa', 'M\'', 'Ga', 'Re', 'Sa'],
        pakadNotes: ['Ni', 'Re', 'Ga', 'M\'', 'Dha', 'Ni', 'Ṡa', 'Pa', 'M\'', 'Ga', 'Re', 'Sa'],
        pakad: 'Ni Re Ga, M\' Dha Ni Ṡa, Pa M\' Ga Re Sa',
        description: 'Serene, romantic, and devotional evening raga using all Shuddha swaras with Teevra Ma (M\').'
    },
    'bhairav': {
        name: 'Raga Bhairav',
        thaat: 'Bhairav',
        prahar: 'Dawn (Early Morning / Sunrise)',
        vadi: 'dha',
        samvadi: 're',
        aarohNotes: ['Sa', 're', 'Ga', 'Ma', 'Pa', 'dha', 'Ni', 'Ṡa'],
        avrohNotes: ['Ṡa', 'Ni', 'dha', 'Pa', 'Ma', 'Ga', 're', 'Sa'],
        pakadNotes: ['Ga', 'Ma', 'dha', 'Pa', 'Ga', 'Ma', 're', 'Sa'],
        pakad: 'Ga Ma dha Pa, Ga Ma re Sa',
        description: 'Majestic morning raga characterized by soulful oscillatory andolan on Komal re and Komal dha.'
    },
    'bhairavi': {
        name: 'Raga Bhairavi',
        thaat: 'Bhairavi',
        prahar: 'Morning / Universal Concluding Raga',
        vadi: 'Ma',
        samvadi: 'Sa',
        aarohNotes: ['Sa', 're', 'ga', 'Ma', 'Pa', 'dha', 'ni', 'Ṡa'],
        avrohNotes: ['Ṡa', 'ni', 'dha', 'Pa', 'Ma', 'ga', 're', 'Sa'],
        pakadNotes: ['Ma', 'ga', 'Sa', 're', 'Sa', 'dha', 'ni', 'Sa'],
        pakad: 'Ma ga Sa re Sa, dha ni Sa',
        description: 'The "Queen of Ragas" using all 4 Komal swaras (re, ga, dha, ni). Evokes sublime devotion and peace.'
    },
    'bilawal': {
        name: 'Raga Bilawal (Alhaiya Bilawal)',
        thaat: 'Bilawal',
        prahar: 'Morning (1st Prahar)',
        vadi: 'Dha',
        samvadi: 'Ga',
        aarohNotes: ['Sa', 'Re', 'Ga', 'Ma', 'Pa', 'Dha', 'Ni', 'Ṡa'],
        avrohNotes: ['Ṡa', 'Ni', 'Dha', 'Pa', 'Ma', 'Ga', 'Re', 'Sa'],
        pakadNotes: ['Ga', 'Re', 'Ga', 'Pa', 'Dha', 'Ni', 'Ṡa'],
        pakad: 'Ga Re Ga Pa, Dha Ni Ṡa',
        description: 'The fundamental major scale of Indian classical music. Joyful, expansive, and auspicious.'
    },
    'bhoopali': {
        name: 'Raga Bhoopali (Bhupali / Bhoop)',
        thaat: 'Kalyan',
        prahar: 'Early Evening (Sandhyakala)',
        vadi: 'Ga',
        samvadi: 'Dha',
        aarohNotes: ['Sa', 'Re', 'Ga', 'Pa', 'Dha', 'Ṡa'],
        avrohNotes: ['Ṡa', 'Dha', 'Pa', 'Ga', 'Re', 'Sa'],
        pakadNotes: ['Ga', 'Re', 'Sa', 'Dha', 'Sa', 'Re', 'Ga', 'Pa', 'Ga'],
        pakad: 'Ga Re Sa Dha, Sa Re Ga Pa Ga',
        description: 'A deeply peaceful 5-note (Audav) pentatonic raga omitting Ma and Ni; symbolizes calm devotion.'
    },
    'kafi': {
        name: 'Raga Kafi',
        thaat: 'Kafi',
        prahar: 'Midnight / Spring (Holi Festival)',
        vadi: 'Pa',
        samvadi: 'Sa',
        aarohNotes: ['Sa', 'Re', 'ga', 'Ma', 'Pa', 'Dha', 'ni', 'Ṡa'],
        avrohNotes: ['Ṡa', 'ni', 'Dha', 'Pa', 'Ma', 'ga', 'Re', 'Sa'],
        pakadNotes: ['Re', 'ga', 'Ma', 'Pa', 'ga', 'Re', 'Sa'],
        pakad: 'Re ga Ma Pa, ga Re Sa',
        description: 'Lively, expressive raga featuring Komal ga and Komal ni; root of vibrant folk and Thumri melodies.'
    },
    'khamaj': {
        name: 'Raga Khamaj',
        thaat: 'Khamaj',
        prahar: 'Late Night (2nd Prahar)',
        vadi: 'Ga',
        samvadi: 'Ni',
        aarohNotes: ['Sa', 'Ga', 'Ma', 'Pa', 'Dha', 'Ni', 'Ṡa'],
        avrohNotes: ['Ṡa', 'ni', 'Dha', 'Pa', 'Ma', 'Ga', 'Re', 'Sa'],
        pakadNotes: ['Ga', 'Ma', 'Pa', 'Dha', 'ni', 'Dha', 'Pa', 'Ma', 'Ga'],
        pakad: 'Ga Ma Pa Dha, ni Dha Pa, Ma Ga',
        description: 'Playful and romantic raga utilizing Shuddha Ni in ascent and Komal ni in descent.'
    },
    'asavari': {
        name: 'Raga Asavari',
        thaat: 'Asavari',
        prahar: 'Late Morning (2nd Prahar)',
        vadi: 'dha',
        samvadi: 'ga',
        aarohNotes: ['Sa', 'Re', 'Ma', 'Pa', 'dha', 'Ṡa'],
        avrohNotes: ['Ṡa', 'ni', 'dha', 'Pa', 'Ma', 'ga', 'Re', 'Sa'],
        pakadNotes: ['Ma', 'Pa', 'dha', 'Pa', 'ga', 'Re', 'Sa'],
        pakad: 'Ma Pa dha Pa, ga Re Sa',
        description: 'Pathos-filled, serious melody featuring Komal ga, Komal dha, and Komal ni.'
    },
    'malkauns': {
        name: 'Raga Malkauns',
        thaat: 'Bhairavi',
        prahar: 'Deep Midnight (3rd Prahar)',
        vadi: 'Ma',
        samvadi: 'Sa',
        aarohNotes: ['Sa', 'ga', 'Ma', 'dha', 'ni', 'Ṡa'],
        avrohNotes: ['Ṡa', 'ni', 'dha', 'Ma', 'ga', 'Sa'],
        pakadNotes: ['ga', 'Ma', 'dha', 'Ma', 'ga', 'Ma', 'ga', 'Sa'],
        pakad: 'ga Ma dha Ma ga, Ma ga Sa',
        description: 'Ancient, meditative Shaivite raga omitting Re and Pa; profound, hypnotic, and introspective.'
    },
    'shivaranjani': {
        name: 'Raga Shivaranjani',
        thaat: 'Kafi',
        prahar: 'Late Evening / Night',
        vadi: 'Pa',
        samvadi: 'Sa',
        aarohNotes: ['Sa', 'Re', 'ga', 'Pa', 'Dha', 'Ṡa'],
        avrohNotes: ['Ṡa', 'Dha', 'Pa', 'ga', 'Re', 'Sa'],
        pakadNotes: ['Sa', 'Re', 'ga', 'Pa', 'Dha', 'Pa', 'ga', 'Re', 'Sa'],
        pakad: 'Sa Re ga Pa, Dha Pa ga Re Sa',
        description: 'Deeply emotional melody beloved in ghazals, bhajans, and soulful classical instrumentals.'
    },
    'bageshri': {
        name: 'Raga Bageshri',
        thaat: 'Kafi',
        prahar: 'Midnight',
        vadi: 'Ma',
        samvadi: 'Sa',
        aarohNotes: ['Sa', 'ga', 'Ma', 'Dha', 'ni', 'Ṡa'],
        avrohNotes: ['Ṡa', 'ni', 'Dha', 'Ma', 'ga', 'Re', 'Sa'],
        pakadNotes: ['Dha', 'ni', 'Sa', 'ga', 'Ma', 'Dha', 'Ma', 'ga'],
        pakad: 'Dha ni Sa, ga Ma, Dha Ma ga',
        description: 'Intimate melody depicting love in anticipation of reunion, featuring Komal ga and Komal ni.'
    },
    'desh': {
        name: 'Raga Desh',
        thaat: 'Khamaj',
        prahar: 'Night (2nd Prahar) / Monsoon',
        vadi: 'Pa',
        samvadi: 'Re',
        aarohNotes: ['Sa', 'Re', 'Ma', 'Pa', 'Ni', 'Ṡa'],
        avrohNotes: ['Ṡa', 'ni', 'Dha', 'Pa', 'Ma', 'Ga', 'Re', 'Sa'],
        pakadNotes: ['Re', 'Ma', 'Pa', 'Ni', 'Ṡa', 'ni', 'Dha', 'Pa'],
        pakad: 'Re Ma Pa Ni Ṡa, ni Dha Pa',
        description: 'Patriotic and romantic raga (basis of Vande Mataram); evokes rainfall and spiritual longing.'
    },
    'durga': {
        name: 'Raga Durga',
        thaat: 'Bilawal',
        prahar: 'Late Night (2nd Prahar)',
        vadi: 'Ma',
        samvadi: 'Sa',
        aarohNotes: ['Sa', 'Re', 'Ma', 'Pa', 'Dha', 'Ṡa'],
        avrohNotes: ['Ṡa', 'Dha', 'Pa', 'Ma', 'Re', 'Sa'],
        pakadNotes: ['Ma', 'Re', 'Pa', 'Dha', 'Ma', 'Re', 'Sa'],
        pakad: 'Ma Re, Pa Dha Ma, Re Sa',
        description: 'Bright and energetic Audav raga omitting Ga and Ni; symbolizes divine strength and joy.'
    },
    'todi': {
        name: 'Raga Todi (Miyan Ki Todi)',
        thaat: 'Todi',
        prahar: 'Late Morning',
        vadi: 'dha',
        samvadi: 'ga',
        aarohNotes: ['Sa', 're', 'ga', 'M\'', 'dha', 'Ni', 'Ṡa'],
        avrohNotes: ['Ṡa', 'Ni', 'dha', 'Pa', 'M\'', 'ga', 're', 'Sa'],
        pakadNotes: ['dha', 'Ni', 'Sa', 're', 'ga', 're', 'Sa'],
        pakad: 'dha Ni Sa re ga, re Sa',
        description: 'Deeply expressive morning raga with Komal re, ga, dha and Teevra M\'.'
    },
    'marwa': {
        name: 'Raga Marwa',
        thaat: 'Marwa',
        prahar: 'Sunset (Sandhiprakash)',
        vadi: 'Dha',
        samvadi: 're',
        aarohNotes: ['Sa', 're', 'Ga', 'M\'', 'Dha', 'Ni', 'Ṡa'],
        avrohNotes: ['Ṡa', 'Ni', 'Dha', 'M\'', 'Ga', 're', 'Sa'],
        pakadNotes: ['Dha', 'M\'', 'Ga', 're', 'Ga', 'M\'', 'Dha'],
        pakad: 'Dha M\' Ga re, Ga M\' Dha',
        description: 'Sunset raga characterized by dramatic yearning; omits Pa with prominent Komal re and Teevra M\'.'
    },
    'darbari': {
        name: 'Raga Darbari Kanada',
        thaat: 'Asavari',
        prahar: 'Midnight',
        vadi: 'Re',
        samvadi: 'Pa',
        aarohNotes: ['Sa', 'Re', 'ga', 'Ma', 'Pa', 'dha', 'ni', 'Ṡa'],
        avrohNotes: ['Ṡa', 'dha', 'ni', 'Pa', 'Ma', 'ga', 're', 'Sa'],
        pakadNotes: ['ga', 'Ma', 'Re', 'Sa', 'dha', 'ni', 'Pa'],
        pakad: 'ga Ma Re Sa, dha ni Pa',
        description: 'Composed by Miyan Tansen for Emperor Akbar\'s royal court; grand, solemn, and regal.'
    },
    'jaunpuri': {
        name: 'Raga Jaunpuri',
        thaat: 'Asavari',
        prahar: 'Morning (Late 1st Prahar)',
        vadi: 'dha',
        samvadi: 'ga',
        aarohNotes: ['Sa', 'Re', 'Ma', 'Pa', 'dha', 'ni', 'Ṡa'],
        avrohNotes: ['Ṡa', 'ni', 'dha', 'Pa', 'Ma', 'ga', 'Re', 'Sa'],
        pakadNotes: ['Ma', 'Pa', 'dha', 'ni', 'dha', 'Pa'],
        pakad: 'Ma Pa dha, ni dha Pa',
        description: 'Melodic morning raga with a pleasant, uplifting mood and sparkling descent.'
    },
    'sarang': {
        name: 'Raga Brindavani Sarang',
        thaat: 'Kafi',
        prahar: 'Midday (Afternoon)',
        vadi: 'Re',
        samvadi: 'Pa',
        aarohNotes: ['Sa', 'Re', 'Ma', 'Pa', 'Ni', 'Ṡa'],
        avrohNotes: ['Ṡa', 'ni', 'Pa', 'Ma', 'Re', 'Sa'],
        pakadNotes: ['Re', 'Ma', 'Pa', 'ni', 'Pa', 'Ma', 'Re'],
        pakad: 'Re Ma Pa, ni Pa Ma Re',
        description: 'Refreshing afternoon raga with Shuddha Ni in ascent and Komal ni in descent.'
    }
};

const RAGA_ALIASES = {
    'bhupali': 'bhoopali',
    'bhoop': 'bhoopali',
    'darbari kanada': 'darbari',
    'darbari kannada': 'darbari',
    'yaman kalyan': 'yaman',
    'kalyan': 'yaman',
    'miyan ki todi': 'todi',
    'alhaiya bilawal': 'bilawal',
    'brindavani sarang': 'sarang',
    'vrindavani sarang': 'sarang',
    'sarang': 'sarang'
};

// Swar to frequency resolver
function resolveSwarInfo(swarRaw, isYamanStart = false) {
    if (!swarRaw) return null;
    const clean = swarRaw.trim();
    
    // Check specific known swars
    if (clean === 'Ṡa' || clean === "Sa'" || clean.toLowerCase() === 'tarsa') {
        return { swar: 'Ṡa', freq: 523.25 };
    }
    if (clean === "M'" || clean.toLowerCase() === "m'" || clean.toLowerCase() === "teevra ma") {
        return { swar: 'M\'', freq: 369.99 };
    }
    if (clean === 're' || clean.toLowerCase() === 'komal re') {
        return { swar: 're', freq: 277.18 };
    }
    if (clean === 'ga' || clean.toLowerCase() === 'komal ga') {
        return { swar: 'ga', freq: 311.13 };
    }
    if (clean === 'dha' || clean.toLowerCase() === 'komal dha') {
        return { swar: 'dha', freq: 415.30 };
    }
    if (clean === 'ni' || clean.toLowerCase() === 'komal ni') {
        return { swar: 'ni', freq: 466.16 };
    }

    // Default Shuddha swaras
    const lower = clean.toLowerCase();
    if (lower === 'sa' || lower === 's') return { swar: 'Sa', freq: 261.63 };
    if (lower === 're' || lower === 'r') return { swar: 'Re', freq: 293.66 };
    if (lower === 'ga' || lower === 'g') return { swar: 'Ga', freq: 329.63 };
    if (lower === 'ma' || lower === 'm') return { swar: 'Ma', freq: 349.23 };
    if (lower === 'pa' || lower === 'p') return { swar: 'Pa', freq: 392.00 };
    if (lower === 'dha' || lower === 'd') return { swar: 'Dha', freq: 440.00 };
    if (lower === 'ni' || lower === 'n') {
        if (isYamanStart) {
            return { swar: 'Ni', freq: 246.94 }; // Mandra Ni in Yaman
        }
        return { swar: 'Ni', freq: 493.88 };
    }

    // Fallback search in HARMONIUM_KEYS
    const found = HARMONIUM_KEYS.find(k => k.swar.toLowerCase() === lower || k.western.toLowerCase() === lower);
    if (found) {
        return { swar: found.swar, freq: found.freq };
    }

    return null;
}

let activeRagaKey = 'yaman';

function initHarmoniumKeyboard() {
    const keysContainer = document.getElementById('harmoniumKeysContainer');
    if (!keysContainer) return;

    // 1. Render Keyboard Keys
    keysContainer.innerHTML = '';
    HARMONIUM_KEYS.forEach(key => {
        const keyEl = document.createElement('div');
        keyEl.setAttribute('data-swar', key.swar);
        keyEl.setAttribute('data-freq', key.freq);

        if (key.isBlack) {
            keyEl.className = 'harm-key-black';
            keyEl.style.left = `${key.leftPercent}%`;
            keyEl.innerHTML = `<span class="swar-label">${key.swar}</span>`;
        } else {
            keyEl.className = 'harm-key-white';
            keyEl.innerHTML = `
                <span class="swar-label">${key.swar}</span>
                <span class="western-note">${key.western}</span>
            `;
        }

        // Manual Touch & Mouse events for student practice
        const pressKey = (e) => {
            e.preventDefault();
            keyEl.classList.add('active');
            if (window.soundEngine) {
                window.soundEngine.playHarmoniumNote(key.freq, key.swar);
            }
        };

        const releaseKey = () => {
            keyEl.classList.remove('active');
            if (window.soundEngine) {
                window.soundEngine.stopHarmoniumNote(key.freq);
            }
        };

        keyEl.addEventListener('mousedown', pressKey);
        keyEl.addEventListener('mouseup', releaseKey);
        keyEl.addEventListener('mouseleave', releaseKey);

        keyEl.addEventListener('touchstart', pressKey);
        keyEl.addEventListener('touchend', releaseKey);

        keysContainer.appendChild(keyEl);
    });

    // 2. Populate Raga Autocomplete Datalist
    const datalist = document.getElementById('ragaAutocompleteList');
    if (datalist) {
        datalist.innerHTML = '';
        Object.keys(INDIAN_RAGA_DATA).forEach(k => {
            const raga = INDIAN_RAGA_DATA[k];
            const opt = document.createElement('option');
            opt.value = raga.name;
            opt.label = `Thaat: ${raga.thaat} • ${raga.prahar}`;
            datalist.appendChild(opt);
        });
    }

    // 3. Preset Raga Chip Buttons
    const ragaChips = document.querySelectorAll('.raga-chip-btn');
    ragaChips.forEach(chip => {
        chip.addEventListener('click', () => {
            ragaChips.forEach(c => c.classList.remove('active'));
            chip.classList.add('active');
            const ragaKey = chip.getAttribute('data-raga');
            const input = document.getElementById('typeRagaInput');
            if (input) input.value = chip.textContent.trim();
            activeRagaKey = ragaKey;
            displayRagaDetails(ragaKey);
            playCurrentRaga();
        });
    });

    // 4. Input Search Listeners
    const ragaInput = document.getElementById('typeRagaInput');
    const playBtn = document.getElementById('playTypedRagaBtn');
    const stopBtn = document.getElementById('stopRagaBtn');
    const clearBtn = document.getElementById('clearRagaInputBtn');
    const modeSelect = document.getElementById('ragaPlayModeSelect');

    if (ragaInput) {
        ragaInput.addEventListener('input', () => {
            const val = ragaInput.value.trim();
            if (clearBtn) clearBtn.style.display = val.length > 0 ? 'block' : 'none';
            if (val.length > 0) {
                checkAndPreviewRaga(val);
            }
        });

        ragaInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                playCurrentRaga();
            }
        });
    }

    if (clearBtn && ragaInput) {
        clearBtn.addEventListener('click', () => {
            ragaInput.value = '';
            clearBtn.style.display = 'none';
            ragaInput.focus();
        });
    }

    if (playBtn) {
        playBtn.addEventListener('click', () => {
            playCurrentRaga();
        });
    }

    if (stopBtn) {
        stopBtn.addEventListener('click', () => {
            stopCurrentRaga();
        });
    }

    if (modeSelect) {
        modeSelect.addEventListener('change', () => {
            displayRagaDetails(activeRagaKey);
        });
    }

    // 5. Sound ON / OFF Toggle Listeners
    const soundToggleBtn = document.getElementById('harmoniumSoundToggleBtn');
    const stripSoundBtn = document.getElementById('harmoniumStripSoundBtn');
    if (soundToggleBtn) soundToggleBtn.addEventListener('click', toggleHarmoniumSound);
    if (stripSoundBtn) stripSoundBtn.addEventListener('click', toggleHarmoniumSound);

    // 6. Reset Keyboard Listeners
    const resetBtn = document.getElementById('harmoniumResetBtn');
    const stripResetBtn = document.getElementById('harmoniumStripResetBtn');
    if (resetBtn) resetBtn.addEventListener('click', resetHarmoniumKeyboard);
    if (stripResetBtn) stripResetBtn.addEventListener('click', resetHarmoniumKeyboard);

    // Initial render of Yaman & Sound state
    displayRagaDetails('yaman');
    if (window.soundEngine) {
        updateHarmoniumSoundUI(window.soundEngine.isMuted);
    }
}

// Sound ON / OFF UI updater
function updateHarmoniumSoundUI(isMuted) {
    const mainBtn = document.getElementById('harmoniumSoundToggleBtn');
    const mainIcon = document.getElementById('harmoniumSoundIcon');
    const mainText = document.getElementById('harmoniumSoundStatusText');
    const stripBtn = document.getElementById('harmoniumStripSoundBtn');
    const stripIcon = document.getElementById('stripSoundIcon');
    const stripText = document.getElementById('stripSoundText');
    const led = document.getElementById('harmoniumLedIndicator');
    const bellowsLabel = document.getElementById('harmoniumBellowsStatusLabel');

    if (isMuted) {
        if (mainBtn) mainBtn.className = 'harmonium-tool-btn sound-off';
        if (mainIcon) mainIcon.className = 'fas fa-volume-xmark';
        if (mainText) mainText.textContent = 'Sound: OFF';
        if (stripBtn) stripBtn.className = 'btn btn-outline-danger';
        if (stripIcon) stripIcon.className = 'fas fa-volume-xmark';
        if (stripText) stripText.textContent = 'Sound: OFF';
        if (led) led.className = 'harmonium-reed-status-led muted';
        if (bellowsLabel) {
            bellowsLabel.textContent = 'Muted (Silent Practice Mode)';
            bellowsLabel.style.color = '#f87171';
        }
    } else {
        if (mainBtn) mainBtn.className = 'harmonium-tool-btn sound-on';
        if (mainIcon) mainIcon.className = 'fas fa-volume-high';
        if (mainText) mainText.textContent = 'Sound: ON';
        if (stripBtn) stripBtn.className = 'btn btn-outline-gold';
        if (stripIcon) stripIcon.className = 'fas fa-volume-high';
        if (stripText) stripText.textContent = 'Sound: ON';
        if (led) led.className = 'harmonium-reed-status-led';
        if (bellowsLabel) {
            bellowsLabel.textContent = 'Bellows Pumping • Sound: ON';
            bellowsLabel.style.color = '#f3dc8f';
        }
    }
}

// Toggle Harmonium Sound ON and OFF
function toggleHarmoniumSound() {
    if (window.soundEngine) {
        const isMuted = window.soundEngine.toggleMute();
        updateHarmoniumSoundUI(isMuted);

        const statusEl = document.getElementById('ragaPlayingStatus');
        if (statusEl) {
            statusEl.innerHTML = isMuted 
                ? `<span style="color: #f87171; font-weight: 700;">🔇 Harmonium Sound is now OFF. Keys can be pressed for silent finger drills.</span>`
                : `<span style="color: #4ade80; font-weight: 700;">🔊 Harmonium Sound is now ON. Acoustic reed simulation enabled.</span>`;
        }
    }
}

// Reset Harmonium Keyboard (stop sounds, clear stuck keys, reset state)
function resetHarmoniumKeyboard() {
    // 1. Stop all audio & cancel active raga melody
    if (window.soundEngine) {
        window.soundEngine.resetAll();
    }

    // 2. Clear all active / playing-reed highlights from all 13 harmonium keys
    document.querySelectorAll('.harm-key-white, .harm-key-black').forEach(k => {
        k.classList.remove('active', 'playing-reed');
    });

    // 3. Clear all active highlights from swara breadcrumb pills
    document.querySelectorAll('.raga-swar-pill').forEach(p => {
        p.classList.remove('current-playing');
    });

    // 4. Reset Play / Stop buttons
    const playBtn = document.getElementById('playTypedRagaBtn');
    const stopBtn = document.getElementById('stopRagaBtn');
    if (playBtn) playBtn.style.display = 'inline-flex';
    if (stopBtn) stopBtn.style.display = 'none';

    // 5. Reset status and feedbacks
    const currentModeStatus = document.getElementById('ragaCurrentModeStatus');
    if (currentModeStatus) {
        currentModeStatus.textContent = 'Ready to Play (Reset)';
    }

    const playingStatus = document.getElementById('ragaPlayingStatus');
    if (playingStatus) {
        playingStatus.innerHTML = `<span style="color: #4ade80; font-weight: 700;">✓ Harmonium keyboard reset successfully! All sounds stopped and keys cleared.</span>`;
    }

    const feedbackEl = document.getElementById('ragaSearchFeedback');
    if (feedbackEl) {
        feedbackEl.textContent = '';
    }

    // 6. Re-render clean active raga details
    displayRagaDetails(activeRagaKey);
}

// Check and preview typed raga or custom notation
function checkAndPreviewRaga(query) {
    const rawLower = query.trim().toLowerCase();
    const clean = rawLower.replace(/^raga\s+/, '').replace(/\s+/g, '');

    let foundKey = null;

    if (INDIAN_RAGA_DATA[rawLower]) {
        foundKey = rawLower;
    } else if (INDIAN_RAGA_DATA[clean]) {
        foundKey = clean;
    } else if (RAGA_ALIASES[rawLower]) {
        foundKey = RAGA_ALIASES[rawLower];
    } else if (RAGA_ALIASES[clean]) {
        foundKey = RAGA_ALIASES[clean];
    } else {
        const match = Object.keys(INDIAN_RAGA_DATA).find(k => {
            const r = INDIAN_RAGA_DATA[k];
            return r.name.toLowerCase().includes(rawLower) || rawLower.includes(k);
        });
        if (match) foundKey = match;
    }

    const feedbackEl = document.getElementById('ragaSearchFeedback');

    if (foundKey) {
        activeRagaKey = foundKey;
        displayRagaDetails(foundKey);

        // Highlight matching chip
        const chips = document.querySelectorAll('.raga-chip-btn');
        chips.forEach(c => {
            if (c.getAttribute('data-raga') === foundKey) {
                c.classList.add('active');
            } else {
                c.classList.remove('active');
            }
        });

        if (feedbackEl) {
            feedbackEl.innerHTML = `<span style="color: #4ade80; font-weight: 700;">✓ Raga "${INDIAN_RAGA_DATA[foundKey].name}" recognized.</span> Press <strong>Play Raga</strong> or change mode.`;
        }
    } else {
        // Check if user is typing custom swaras (e.g. "Sa Re Ga Ma Pa Dha Ni Sa")
        const tokens = query.split(/[\s,-]+/).filter(t => t.length > 0);
        const validTokens = tokens.filter(t => resolveSwarInfo(t) !== null);

        if (validTokens.length >= 2) {
            displayCustomSwaraDetails(validTokens);
            if (feedbackEl) {
                feedbackEl.innerHTML = `<span style="color: #f3dc8f; font-weight: 700;">🎼 Custom Swara Sequence Detected (${validTokens.length} swaras):</span> Press <strong>Play Raga</strong> to hear on harmonium!`;
            }
        } else {
            if (feedbackEl) {
                feedbackEl.innerHTML = `Type any Raga name (e.g. <em>Yaman, Bhairav, Bhairavi, Bhoopali, Kafi, Malkauns, Darbari</em>) or custom swaras (<em>Sa Re Ga Ma Pa</em>).`;
            }
        }
    }
}

// Display Details for a Recognized Classical Raga
function displayRagaDetails(ragaKey) {
    const raga = INDIAN_RAGA_DATA[ragaKey] || INDIAN_RAGA_DATA['yaman'];
    const titleEl = document.getElementById('ragaDisplayName');
    const badgeEl = document.getElementById('ragaThaatBadge');
    const metaEl = document.getElementById('ragaMetaDetails');
    const pakadEl = document.getElementById('ragaPakadDisplay');
    const breadcrumbsWrap = document.getElementById('ragaSwaraLiveBreadcrumbs');
    const modeSelect = document.getElementById('ragaPlayModeSelect');

    const mode = modeSelect ? modeSelect.value : 'full';

    if (titleEl) titleEl.textContent = raga.name;
    if (badgeEl) badgeEl.textContent = `Thaat: ${raga.thaat}`;
    if (metaEl) {
        metaEl.textContent = `Time: ${raga.prahar} • Vadi: ${raga.vadi} • Samvadi: ${raga.samvadi} • ${raga.description}`;
    }
    if (pakadEl) {
        pakadEl.textContent = `Pakad (Catch Phrase): ${raga.pakad}`;
    }

    if (!breadcrumbsWrap) return;
    breadcrumbsWrap.innerHTML = '';

    let swaraList = [];
    if (mode === 'aaroh') {
        swaraList = raga.aarohNotes;
    } else if (mode === 'avroh') {
        swaraList = raga.avrohNotes;
    } else if (mode === 'pakad') {
        swaraList = raga.pakadNotes || raga.aarohNotes;
    } else {
        swaraList = [...raga.aarohNotes, '—', ...raga.avrohNotes];
    }

    swaraList.forEach((swar, idx) => {
        const pill = document.createElement('span');
        if (swar === '—') {
            pill.style.cssText = 'color: #888; font-weight: 700; margin: 0 4px;';
            pill.textContent = '⇌';
        } else {
            pill.className = 'raga-swar-pill';
            pill.id = `ragaPill_${idx}`;
            pill.textContent = swar;
        }
        breadcrumbsWrap.appendChild(pill);
    });
}

// Display custom swara sequence
function displayCustomSwaraDetails(swaraTokens) {
    const titleEl = document.getElementById('ragaDisplayName');
    const badgeEl = document.getElementById('ragaThaatBadge');
    const metaEl = document.getElementById('ragaMetaDetails');
    const pakadEl = document.getElementById('ragaPakadDisplay');
    const breadcrumbsWrap = document.getElementById('ragaSwaraLiveBreadcrumbs');

    if (titleEl) titleEl.textContent = 'Custom Swara Riyaz Sequence';
    if (badgeEl) badgeEl.textContent = 'User Defined';
    if (metaEl) metaEl.textContent = 'Sequential Swara Riyaz on Saptaveena Harmonium Reeds';
    if (pakadEl) pakadEl.textContent = `Swaras: ${swaraTokens.join(' - ')}`;

    if (!breadcrumbsWrap) return;
    breadcrumbsWrap.innerHTML = '';

    swaraTokens.forEach((swar, idx) => {
        const pill = document.createElement('span');
        pill.className = 'raga-swar-pill';
        pill.id = `ragaPill_${idx}`;
        pill.textContent = swar;
        breadcrumbsWrap.appendChild(pill);
    });
}

// Play the active raga or custom sequence on the Harmonium
async function playCurrentRaga() {
    if (!window.soundEngine) return;

    const input = document.getElementById('typeRagaInput');
    const modeSelect = document.getElementById('ragaPlayModeSelect');
    const tempoSelect = document.getElementById('ragaTempoSelect');
    const playBtn = document.getElementById('playTypedRagaBtn');
    const stopBtn = document.getElementById('stopRagaBtn');
    const statusEl = document.getElementById('ragaCurrentModeStatus');

    const mode = modeSelect ? modeSelect.value : 'full';
    const tempo = tempoSelect ? parseInt(tempoSelect.value, 10) : 500;

    let notesToPlay = [];
    let ragaTitle = '';

    // Check if user typed custom swaras
    const inputVal = input ? input.value.trim() : '';
    const tokens = inputVal.split(/[\s,-]+/).filter(t => t.length > 0);
    const validTokens = tokens.map(t => resolveSwarInfo(t)).filter(t => t !== null);

    if (validTokens.length >= 2 && !INDIAN_RAGA_DATA[inputVal.toLowerCase()] && !RAGA_ALIASES[inputVal.toLowerCase()]) {
        notesToPlay = validTokens.map(t => ({ freq: t.freq, swar: t.swar }));
        ragaTitle = 'Custom Swara Sequence';
    } else {
        const raga = INDIAN_RAGA_DATA[activeRagaKey] || INDIAN_RAGA_DATA['yaman'];
        ragaTitle = raga.name;

        let swarNames = [];
        if (mode === 'aaroh') {
            swarNames = raga.aarohNotes;
        } else if (mode === 'avroh') {
            swarNames = raga.avrohNotes;
        } else if (mode === 'pakad') {
            swarNames = raga.pakadNotes || raga.aarohNotes;
        } else {
            swarNames = [...raga.aarohNotes, ...raga.avrohNotes];
        }

        notesToPlay = swarNames.map((s, idx) => {
            const isYamanStart = activeRagaKey === 'yaman' && idx === 0 && s === 'Ni';
            const resolved = resolveSwarInfo(s, isYamanStart);
            return {
                swar: s,
                freq: resolved ? resolved.freq : 261.63
            };
        });
    }

    if (notesToPlay.length === 0) return;

    // Toggle button states
    if (playBtn) playBtn.style.display = 'none';
    if (stopBtn) stopBtn.style.display = 'inline-flex';
    if (statusEl) statusEl.innerHTML = `<span style="color: #4ade80;">Playing ${ragaTitle}...</span>`;

    // Visual breadcrumbs & keyboard key highlighting callback
    const onProgress = (note, index, isNoteActive) => {
        // 1. Highlight pill
        const pill = document.getElementById(`ragaPill_${index}`);
        if (pill) {
            if (isNoteActive) {
                pill.classList.add('current-playing');
            } else {
                pill.classList.remove('current-playing');
            }
        }

        // 2. Highlight matching harmonium key
        const keysContainer = document.getElementById('harmoniumKeysContainer');
        if (keysContainer) {
            // Match by swar or closest frequency
            const allKeys = keysContainer.querySelectorAll('.harm-key-white, .harm-key-black');
            allKeys.forEach(k => {
                const kFreq = parseFloat(k.getAttribute('data-freq'));
                const kSwar = k.getAttribute('data-swar');
                if (Math.abs(kFreq - note.freq) < 1.0 || (kSwar && kSwar === note.swar)) {
                    if (isNoteActive) {
                        k.classList.add('playing-reed', 'active');
                    } else {
                        k.classList.remove('playing-reed', 'active');
                    }
                }
            });
        }

        // 3. Status text
        if (statusEl && isNoteActive) {
            statusEl.innerHTML = `<span style="color: #f3dc8f;">♫ Swar: <strong>${note.swar}</strong> (${note.freq.toFixed(1)} Hz)</span>`;
        }
    };

    // Execute through Web Audio API synth
    await window.soundEngine.playMelody(notesToPlay, tempo, onProgress);

    // Reset controls after completion
    stopCurrentRaga();
}

// Stop current raga playback
function stopCurrentRaga() {
    if (window.soundEngine) {
        window.soundEngine.stopMelody();
    }

    const playBtn = document.getElementById('playTypedRagaBtn');
    const stopBtn = document.getElementById('stopRagaBtn');
    const statusEl = document.getElementById('ragaCurrentModeStatus');

    if (playBtn) playBtn.style.display = 'inline-flex';
    if (stopBtn) stopBtn.style.display = 'none';
    if (statusEl) statusEl.textContent = 'Ready to Play';

    // Remove active highlights
    document.querySelectorAll('.raga-swar-pill').forEach(p => p.classList.remove('current-playing'));
    document.querySelectorAll('.harm-key-white, .harm-key-black').forEach(k => k.classList.remove('playing-reed', 'active'));
}

// ==========================================
// 7. Exams & Year-End Certification Generator
// ==========================================
function initCertGenerator() {
    // Populate student select box
    const studentSelect = document.getElementById('certStudentSelect');
    const nameInput = document.getElementById('certStudentNameInput');
    const discSelect = document.getElementById('certDisciplineSelect');
    const gradeSelect = document.getElementById('certGradeSelect');
    const dateInput = document.getElementById('certDateInput');

    if (dateInput) {
        dateInput.value = new Date().toISOString().split('T')[0];
    }

    if (studentSelect && window.studentDb) {
        studentSelect.innerHTML = '<option value="">-- Choose from Enrolled Students --</option>';
        window.studentDb.getAll().forEach(s => {
            const opt = document.createElement('option');
            opt.value = s.id;
            opt.textContent = `${s.name} (${s.discipline} - ${s.mode})`;
            studentSelect.appendChild(opt);
        });

        studentSelect.addEventListener('change', () => {
            const sid = studentSelect.value;
            if (!sid) return;
            const stu = window.studentDb.getById(sid);
            if (stu) {
                if (nameInput) nameInput.value = stu.name;
                if (discSelect) discSelect.value = stu.discipline;
                if (gradeSelect) gradeSelect.value = stu.grade && stu.grade !== 'In Progress' ? stu.grade : 'Distinction';
                updateCertificatePreview();
            }
        });
    }

    // Input event listeners for real-time live preview
    [nameInput, discSelect, gradeSelect, dateInput].forEach(inp => {
        if (inp) {
            inp.addEventListener('input', updateCertificatePreview);
            inp.addEventListener('change', updateCertificatePreview);
        }
    });

    // Print & Download Buttons
    const printCertBtn = document.getElementById('printCertBtn');
    if (printCertBtn) {
        printCertBtn.addEventListener('click', () => {
            const certElement = document.getElementById('officialCertificateFrame');
            if (certElement) {
                certElement.classList.add('printable-area');
                window.print();
                certElement.classList.remove('printable-area');
            }
        });
    }

    // Interactive Quiz Test
    const quizForm = document.getElementById('onlineExamQuizForm');
    const quizResultBox = document.getElementById('quizResultBox');
    if (quizForm && quizResultBox) {
        quizForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const answers = {
                q1: 'd', // Teentaal 16 matras
                q2: 'b', // 6 strings standard guitar
                q3: 'c', // Red, Yellow, Blue primary
                q4: 'a'  // Sa Re Ga Ma Pa Dha Ni
            };

            let score = 0;
            const formData = new FormData(quizForm);
            for (let [key, val] of formData.entries()) {
                if (answers[key] === val) score += 25;
            }

            quizResultBox.style.display = 'block';
            let grade = score >= 90 ? 'Distinction' : score >= 75 ? 'A+' : score >= 50 ? 'A' : 'Needs Practice';
            quizResultBox.innerHTML = `
                <div style="background: #f0fdf4; border: 1.5px solid #86efac; border-radius: 12px; padding: 16px; color: #166534;">
                    <h4 style="font-size: 1.1rem; margin-bottom: 6px;">Exam Completed! Score: ${score}/100 (${grade})</h4>
                    <p style="font-size: 0.88rem;">${score >= 50 ? 'Congratulations! You have passed the Saptaveena Academy theoretical evaluation and are eligible for your official Year-End Certificate.' : 'Please review your course notes with your mentor before retaking the assessment.'}</p>
                </div>
            `;

            if (score >= 50 && nameInput && nameInput.value.trim()) {
                if (gradeSelect) gradeSelect.value = grade;
                updateCertificatePreview();
            }
        });
    }

    updateCertificatePreview();
}

function updateCertificatePreview() {
    const nameVal = document.getElementById('certStudentNameInput')?.value || "Debanjan Roy";
    const discVal = document.getElementById('certDisciplineSelect')?.value || "Guitar";
    const gradeVal = document.getElementById('certGradeSelect')?.value || "Distinction";
    const dateVal = document.getElementById('certDateInput')?.value || new Date().toISOString().split('T')[0];

    const prevName = document.getElementById('previewCertName');
    const prevDisc = document.getElementById('previewCertDiscipline');
    const prevGrade = document.getElementById('previewCertGrade');
    const prevDate = document.getElementById('previewCertDate');
    const prevId = document.getElementById('previewCertId');

    if (prevName) prevName.textContent = nameVal;
    if (prevDisc) prevDisc.textContent = discVal;
    if (prevGrade) prevGrade.textContent = gradeVal;
    if (prevDate) prevDate.textContent = formatDate(dateVal);
    if (prevId) {
        const discLetter = discVal.charAt(0).toUpperCase();
        prevId.textContent = `SAPTA-CERT-2026-${discLetter}${Math.abs(hashString(nameVal)) % 1000}`;
    }

    const sigSignature = document.getElementById('certSignatorySignature');
    const sigName = document.getElementById('certSignatoryName');
    const sigRole = document.getElementById('certSignatoryRole');
    if (sigSignature) sigSignature.textContent = "Sushmita Saha";
    if (sigName) sigName.textContent = "Sushmita Saha";
    if (sigRole) sigRole.textContent = "Director and Chief Academic Mentor";
}

// ==========================================
// 8. Unified Student Database UI
// ==========================================
function initStudentDatabase() {
    filterAndRenderStudents();
    loadAcademyEvents();

    window.addEventListener('saptavina:backend-status', (e) => {
        if (e.detail && e.detail.isOnline) {
            filterAndRenderStudents();
            loadAcademyEvents();
        }
    });

    // Filters
    const discFilter = document.getElementById('dbFilterDiscipline');
    const modeFilter = document.getElementById('dbFilterMode');
    const payFilter = document.getElementById('dbFilterPayment');
    const searchInp = document.getElementById('dbSearchInput');

    [discFilter, modeFilter, payFilter].forEach(el => {
        if (el) el.addEventListener('change', () => filterAndRenderStudents());
    });
    if (searchInp) {
        searchInp.addEventListener('input', () => filterAndRenderStudents());
    }

    // Export CSV
    const exportBtn = document.getElementById('dbExportCsvBtn');
    if (exportBtn) {
        exportBtn.addEventListener('click', exportStudentsToCSV);
    }
}

async function filterAndRenderStudents() {
    const disc = document.getElementById('dbFilterDiscipline')?.value || 'all';
    const mode = document.getElementById('dbFilterMode')?.value || 'all';
    const pay = document.getElementById('dbFilterPayment')?.value || 'all';
    const query = document.getElementById('dbSearchInput')?.value || '';

    let list = [];
    if (window.saptavinaAPI && window.saptavinaAPI.backendAvailable) {
        list = await window.saptavinaAPI.getStudents({ discipline: disc, mode, payment_status: pay, search: query });
    } else if (window.studentDb) {
        list = window.studentDb.filter(disc, mode, pay, query);
    }
    renderStudentsTable(list);
    await updateDatabaseMetrics();
}

function renderStudentsTable(data = null) {
    const tableBody = document.getElementById('studentsTableBody');
    if (!tableBody) return;

    const list = data || (window.studentDb ? window.studentDb.getAll() : []);
    tableBody.innerHTML = '';

    if (!list || list.length === 0) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="7" style="text-align: center; padding: 28px; color: #777;">
                    No student records match the selected filters.
                </td>
            </tr>
        `;
        return;
    }

    list.forEach(stu => {
        const row = document.createElement('tr');
        const paymentStatus = stu.paymentStatus || stu.payment_status || 'Pending';
        const attendancePercent = stu.attendancePercent !== undefined ? stu.attendancePercent : (stu.attendance_percent || 100);
        const classesAttended = stu.classesAttended !== undefined ? stu.classesAttended : (stu.classes_attended || 0);
        const totalClasses = stu.totalClasses !== undefined ? stu.totalClasses : (stu.total_classes || 0);
        const tuition = stu.tuitionFee || stu.tuition_fee || 399;
        const admission = stu.admissionFee || stu.admission_fee || 50;

        const payStatusClass = paymentStatus === 'Paid' ? 'status-paid' :
                               paymentStatus === 'Pending' ? 'status-pending' : 'status-overdue';

        const modeBadgeClass = stu.mode === 'Online' ? 'mode-online' : 'mode-offline';
        const batchDisplay = (stu.batch || '').split('(')[0];

        row.innerHTML = `
            <td>
                <strong>${escapeHTML(stu.name)}</strong>
                <div style="font-size: 0.74rem; color: #888;">${stu.id}</div>
            </td>
            <td>
                <strong>${stu.discipline}</strong>
                <div style="font-size: 0.76rem; color: #666;">${batchDisplay}</div>
            </td>
            <td>
                <span class="mode-badge-pill ${modeBadgeClass}">${stu.mode}</span>
            </td>
            <td>
                <div style="font-size: 0.82rem; font-weight: 700;">${attendancePercent}%</div>
                <div style="font-size: 0.72rem; color: #777;">${classesAttended}/${totalClasses} classes</div>
            </td>
            <td>
                <span class="status-badge ${payStatusClass}">
                    ● ${paymentStatus}
                </span>
                <div style="font-size: 0.72rem; color: #888; margin-top: 2px;">
                    ₹${tuition + admission}
                </div>
            </td>
            <td>
                <span style="font-weight: 700; color: #4a0d17;">${stu.grade || 'In Progress'}</span>
            </td>
            <td>
                <div style="display: flex; gap: 6px;">
                    ${paymentStatus !== 'Paid' ? `
                        <button class="btn btn-outline" style="padding: 4px 8px; font-size: 0.74rem;" onclick="quickMarkPaid('${stu.id}')">
                            Mark Paid
                        </button>
                    ` : `
                        <button class="btn btn-outline-gold" style="padding: 4px 8px; font-size: 0.74rem;" onclick="openReceiptForStudent('${stu.id}')">
                            Receipt
                        </button>
                    `}
                    <button class="btn btn-primary" style="padding: 4px 8px; font-size: 0.74rem;" onclick="loadCertForStudent('${stu.id}')">
                        Certificate
                    </button>
                </div>
            </td>
        `;
        tableBody.appendChild(row);
    });
}

async function updateDatabaseMetrics() {
    let summary = null;
    if (window.saptavinaAPI && window.saptavinaAPI.backendAvailable) {
        summary = await window.saptavinaAPI.getFinancialSummary();
    } else if (window.studentDb) {
        summary = window.studentDb.getFinancialSummary();
    }
    if (!summary) return;

    const totalEl = document.getElementById('metricTotalStudents');
    const collectedEl = document.getElementById('metricTotalCollected');
    const pendingEl = document.getElementById('metricPendingDues');
    const expectedEl = document.getElementById('metricExpectedMonthly');

    const totalVal = summary.total_students !== undefined ? summary.total_students : summary.totalStudents;
    const collectedVal = summary.total_collected_inr !== undefined ? summary.total_collected_inr : summary.totalCollected;
    const pendingVal = summary.pending_count !== undefined ? summary.pending_count : (summary.pendingCount + (summary.overdueCount || 0));
    const expectedVal = summary.expected_monthly_inr !== undefined ? summary.expected_monthly_inr : summary.expectedMonthly;

    if (totalEl) totalEl.textContent = totalVal || 0;
    if (collectedEl) collectedEl.textContent = `₹${(collectedVal || 0).toLocaleString('en-IN')}`;
    if (pendingEl) pendingEl.textContent = `${pendingVal || 0} Students`;
    if (expectedEl) expectedEl.textContent = `₹${(expectedVal || 0).toLocaleString('en-IN')}`;
}

async function loadAcademyEvents() {
    const eventsContainer = document.getElementById('eventsGrid');
    if (!eventsContainer || !window.saptavinaAPI) return;

    try {
        const events = await window.saptavinaAPI.getEvents();
        if (Array.isArray(events) && events.length > 0) {
            eventsContainer.innerHTML = events.map(ev => `
                <div class="schedule-card">
                    <div class="schedule-time-badge" style="background: var(--gold-600); color: #1f1a1b;">
                        ${escapeHTML(ev.type || 'Showcase')}
                    </div>
                    <h3>${escapeHTML(ev.title)}</h3>
                    <p style="font-size: 0.88rem; color: #666; margin: 10px 0 16px;">
                        ${escapeHTML(ev.description)}
                    </p>
                    <div style="font-size: 0.82rem; color: #5c1322; font-weight: 700;">
                        📍 ${escapeHTML(ev.location)} • ${escapeHTML(ev.date)}
                    </div>
                </div>
            `).join('');
        }
    } catch (e) {
        console.warn("Could not load dynamic events, keeping static cards", e);
    }
}

window.quickMarkPaid = function(id) {
    if (window.studentDb) {
        const txnId = `UPI/${Date.now().toString().slice(-10)}`;
        window.studentDb.updatePaymentStatus(id, 'Paid', 'UPI Direct', txnId);
        filterAndRenderStudents();
        openReceiptForStudent(id);
    }
};

window.loadCertForStudent = function(id) {
    const stu = window.studentDb.getById(id);
    if (!stu) return;

    const nameInp = document.getElementById('certStudentNameInput');
    const discInp = document.getElementById('certDisciplineSelect');
    const gradeInp = document.getElementById('certGradeSelect');
    const selectBox = document.getElementById('certStudentSelect');

    if (nameInp) nameInp.value = stu.name;
    if (discInp) discInp.value = stu.discipline;
    if (gradeInp) gradeInp.value = stu.grade && stu.grade !== 'In Progress' ? stu.grade : 'Distinction';
    if (selectBox) selectBox.value = stu.id;

    updateCertificatePreview();

    const certSec = document.getElementById('exams');
    if (certSec) {
        certSec.scrollIntoView({ behavior: 'smooth' });
    }
};

function exportStudentsToCSV() {
    if (!window.studentDb) return;
    const students = window.studentDb.getAll();
    let csv = "ID,Name,Discipline,Mode,Batch,Phone,PaymentStatus,TuitionFee,AdmissionFee,AttendancePercent,Grade,CertificateID\n";

    students.forEach(s => {
        csv += `"${s.id}","${s.name}","${s.discipline}","${s.mode}","${s.batch}","${s.phone}","${s.paymentStatus}",${s.tuitionFee},${s.admissionFee},${s.attendancePercent},"${s.grade}","${s.certificateId || ''}"\n`;
    });

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `saptaveena_student_records_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
}

// ==========================================
// 9. Payment Gateway & Receipt Generator
// ==========================================
let currentCheckoutAmount = 449;

function initPaymentGateway() {
    // Fee options toggle (New Admission ₹449 vs Monthly Renewal ₹399)
    const amountToggles = document.querySelectorAll('.pay-amount-toggle');
    amountToggles.forEach(toggle => {
        toggle.addEventListener('click', () => {
            amountToggles.forEach(t => t.classList.remove('active'));
            toggle.classList.add('active');
            currentCheckoutAmount = parseInt(toggle.getAttribute('data-amount'), 10) || 449;
            updatePaymentQR(currentCheckoutAmount);
        });
    });

    // Payment Methods Tab (QR / UPI ID / Bank Transfer)
    const payMethodTabs = document.querySelectorAll('.pay-tab-btn');
    const payPanes = document.querySelectorAll('.payment-method-pane');
    payMethodTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            payMethodTabs.forEach(t => t.classList.remove('active'));
            payPanes.forEach(p => p.classList.remove('active'));
            tab.classList.add('active');
            const targetId = tab.getAttribute('data-pay-target');
            const pane = document.getElementById(targetId);
            if (pane) pane.classList.add('active');
        });
    });

    // Copy Buttons
    const copyBtns = document.querySelectorAll('.copy-trigger');
    copyBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const textToCopy = btn.getAttribute('data-copy-text');
            if (textToCopy) {
                navigator.clipboard.writeText(textToCopy).then(() => {
                    const originalText = btn.innerHTML;
                    btn.innerHTML = `<span style="color: #15803d;">Copied!</span>`;
                    setTimeout(() => { btn.innerHTML = originalText; }, 1800);
                });
            }
        });
    });

    // Verification Form (Student submits UTR/Txn ID)
    const verifyForm = document.getElementById('paymentVerifyForm');
    if (verifyForm) {
        verifyForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const stuName = document.getElementById('payVerifyStudentName').value.trim();
            const stuPhone = document.getElementById('payVerifyStudentPhone').value.trim();
            const txnId = document.getElementById('payVerifyTxnId').value.trim();
            const payMode = document.getElementById('payVerifyMethod').value;

            // Check if student exists in database or add them
            let student = window.studentDb.getByPhone(stuPhone);
            if (student) {
                window.studentDb.updatePaymentStatus(student.id, 'Paid', payMode, txnId);
            } else {
                student = window.studentDb.addStudent({
                    name: stuName,
                    phone: stuPhone,
                    discipline: "Guitar",
                    paymentStatus: "Paid",
                    lastPaymentMode: payMode,
                    lastTxnId: txnId
                });
            }

            filterAndRenderStudents();
            openReceiptForStudent(student.id, txnId, currentCheckoutAmount);
            verifyForm.reset();
        });
    }

    // Print Receipt button
    const printReceiptBtn = document.getElementById('printReceiptModalBtn');
    if (printReceiptBtn) {
        printReceiptBtn.addEventListener('click', () => {
            const receiptArea = document.getElementById('printableReceiptArea');
            if (receiptArea) {
                receiptArea.classList.add('printable-area');
                window.print();
                receiptArea.classList.remove('printable-area');
            }
        });
    }
}

window.openReceiptForStudent = function(studentId, customTxnId = '', amount = 449) {
    const stu = window.studentDb.getById(studentId);
    if (!stu) return;

    const modal = document.getElementById('receiptModal');
    if (!modal) return;

    const receiptNo = `SAPTA-REC-2026-${Math.abs(hashString(stu.id + Date.now())) % 10000}`;
    const dateStr = formatDate(new Date().toISOString().split('T')[0]);
    const txnIdVal = customTxnId || stu.lastTxnId || `UPI/${Date.now().toString().slice(-10)}`;
    const payModeVal = stu.lastPaymentMode || 'UPI QR';

    const tuition = stu.tuitionFee || 399;
    const admission = amount === 449 ? 50 : 0;
    const total = tuition + admission;

    const el = id => document.getElementById(id);

    // Update Section Printable Receipt (if present on page)
    if (el('receiptNoDisplay')) el('receiptNoDisplay').textContent = receiptNo;
    if (el('receiptDateDisplay')) el('receiptDateDisplay').textContent = dateStr;
    if (el('receiptStudentName')) el('receiptStudentName').textContent = stu.name;
    if (el('receiptStudentId')) el('receiptStudentId').textContent = stu.id;
    if (el('receiptDiscipline')) el('receiptDiscipline').textContent = `${stu.discipline} (${stu.mode})`;
    if (el('receiptTxnId')) el('receiptTxnId').textContent = txnIdVal;
    if (el('receiptPayMode')) el('receiptPayMode').textContent = `${payModeVal} / `;
    if (el('receiptTuitionFee')) el('receiptTuitionFee').textContent = `₹${tuition}/-`;
    if (el('receiptAdmissionFee')) el('receiptAdmissionFee').textContent = `₹${admission}/-`;
    if (el('receiptTotalAmount')) el('receiptTotalAmount').textContent = `₹${total}/-`;

    // Update Modal Printable Receipt Elements
    if (el('modalReceiptNoDisplay')) el('modalReceiptNoDisplay').textContent = receiptNo;
    if (el('modalReceiptDateDisplay')) el('modalReceiptDateDisplay').textContent = dateStr;
    if (el('modalReceiptStudentName')) el('modalReceiptStudentName').textContent = stu.name;
    if (el('modalReceiptStudentId')) el('modalReceiptStudentId').textContent = stu.id;
    if (el('modalReceiptDiscipline')) el('modalReceiptDiscipline').textContent = `${stu.discipline} (${stu.mode} Mode)`;
    if (el('modalReceiptTxnId')) el('modalReceiptTxnId').textContent = txnIdVal;
    if (el('modalReceiptPayMode')) el('modalReceiptPayMode').textContent = `${payModeVal} / `;
    if (el('modalReceiptTuitionFee')) el('modalReceiptTuitionFee').textContent = `₹${tuition}/-`;
    if (el('modalReceiptAdmissionFee')) el('modalReceiptAdmissionFee').textContent = `₹${admission}/-`;
    if (el('modalReceiptTotalAmount')) el('modalReceiptTotalAmount').textContent = `₹${total}/-`;

    // Render receipt verification QR codes
    const verifyUrl = `https://saptaveena.edu.in/verify?receipt=${receiptNo}&id=${stu.id}&amt=${total}&payee=Sushmita%20Saha`;
    const receiptQREl = el('receiptVerificationQR');
    if (receiptQREl && window.QRCode) {
        receiptQREl.innerHTML = '';
        new QRCode(receiptQREl, {
            text: verifyUrl,
            width: 76,
            height: 76,
            colorDark: "#3b0912",
            colorLight: "#ffffff"
        });
    }

    const modalReceiptQREl = el('modalReceiptVerificationQR');
    if (modalReceiptQREl && window.QRCode) {
        modalReceiptQREl.innerHTML = '';
        new QRCode(modalReceiptQREl, {
            text: verifyUrl,
            width: 72,
            height: 72,
            colorDark: "#3b0912",
            colorLight: "#ffffff"
        });
    }

    modal.classList.add('active');
};

// ==========================================
// 10. Mentoring Session Booking
// ==========================================
function initMentoringBooking() {
    const bookingForm = document.getElementById('mentoringBookingForm');
    const modal = document.getElementById('bookingConfirmModal');

    // Pre-fill mentor if clicked from card
    const bookButtons = document.querySelectorAll('.book-mentor-btn');
    bookButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const mentorName = btn.getAttribute('data-mentor');
            const mentorSelect = document.getElementById('mentoringMentorSelect');
            if (mentorSelect && mentorName) {
                mentorSelect.value = mentorName;
            }
            const formSec = document.getElementById('mentoringBookingFormContainer');
            if (formSec) {
                formSec.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });

    if (bookingForm && modal) {
        bookingForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const name = document.getElementById('mentorStudentName').value;
            const mentor = document.getElementById('mentoringMentorSelect').value;
            const date = document.getElementById('mentorSessionDate').value;
            const slot = document.getElementById('mentorSessionSlot').value;
            const mode = document.getElementById('mentorSessionMode').value;

            document.getElementById('confirmStudentName').textContent = name;
            document.getElementById('confirmMentorName').textContent = mentor;
            document.getElementById('confirmDateTime').textContent = `${formatDate(date)} at ${slot}`;
            document.getElementById('confirmMode').textContent = mode;

            const meetLink = `https://meet.google.com/sap-${Math.random().toString(36).substring(2, 6)}-${Math.random().toString(36).substring(2, 6)}`;
            document.getElementById('confirmMeetLink').href = meetLink;
            document.getElementById('confirmMeetLink').textContent = meetLink;

            modal.classList.add('active');
            bookingForm.reset();
        });
    }
}

// ==========================================
// 11. Parent Portal Lookup
// ==========================================
function initParentPortal() {
    const form = document.getElementById('parentLookupForm');
    const resultBox = document.getElementById('parentResultContainer');

    if (form && resultBox) {
        form.addEventListener('submit', (e) => {
            e.preventDefault();
            const query = document.getElementById('parentSearchQuery').value.trim();
            if (!query) return;

            const student = window.studentDb.getById(query) || window.studentDb.getByPhone(query);
            resultBox.style.display = 'block';

            if (!student) {
                resultBox.innerHTML = `
                    <div style="background: #fef2f2; border: 1.5px solid #fecaca; border-radius: 14px; padding: 20px; color: #991b1b; text-align: center;">
                        <p style="font-weight: 700;">No student record found for "${escapeHTML(query)}".</p>
                        <p style="font-size: 0.85rem; margin-top: 4px;">Please check the Student ID or registered 10-digit mobile number, or contact the academy at 9163133477.</p>
                    </div>
                `;
                return;
            }

            const payColor = student.paymentStatus === 'Paid' ? '#15803d' : '#b91c1c';
            resultBox.innerHTML = `
                <div style="background: #fff; border: 2px solid #e0d5c1; border-radius: 16px; padding: 24px; box-shadow: 0 4px 14px rgba(0,0,0,0.06);">
                    <div style="display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 1px solid #eee; padding-bottom: 14px; margin-bottom: 16px;">
                        <div>
                            <h3 style="font-family: 'Playfair Display', serif; font-size: 1.4rem; color: #5c1322;">${escapeHTML(student.name)}</h3>
                            <div style="font-size: 0.84rem; color: #666;">ID: ${student.id} | Discipline: <strong>${student.discipline}</strong> (${student.mode})</div>
                            <div style="font-size: 0.82rem; color: #777;">Guardian: ${escapeHTML(student.guardian || 'Registered Parent')}</div>
                        </div>
                        <span class="status-badge" style="background: ${payColor}20; color: ${payColor};">
                            Fee Status: ${student.paymentStatus}
                        </span>
                    </div>

                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 20px;">
                        <div style="background: #fdfbf7; border: 1px solid #eee; padding: 12px; border-radius: 10px; text-align: center;">
                            <div style="font-size: 0.76rem; color: #777; text-transform: uppercase;">Attendance</div>
                            <div style="font-size: 1.4rem; font-weight: 800; color: #5c1322;">${student.attendancePercent}%</div>
                            <div style="font-size: 0.72rem; color: #888;">${student.classesAttended}/${student.totalClasses} classes</div>
                        </div>
                        <div style="background: #fdfbf7; border: 1px solid #eee; padding: 12px; border-radius: 10px; text-align: center;">
                            <div style="font-size: 0.76rem; color: #777; text-transform: uppercase;">Academic Grade</div>
                            <div style="font-size: 1.4rem; font-weight: 800; color: #b8860b;">${student.grade || 'In Progress'}</div>
                            <div style="font-size: 0.72rem; color: #888;">Exam Score: ${student.examScore || '88'}/100</div>
                        </div>
                        <div style="background: #fdfbf7; border: 1px solid #eee; padding: 12px; border-radius: 10px; text-align: center;">
                            <div style="font-size: 0.76rem; color: #777; text-transform: uppercase;">Saturday Batch</div>
                            <div style="font-size: 0.88rem; font-weight: 700; color: #333; margin-top: 6px;">${student.batch.split('(')[0]}</div>
                            <div style="font-size: 0.72rem; color: #888;">${student.batch.includes('10:00') ? '10 AM - 12 PM' : student.batch.includes('12:00') ? '12 PM - 2 PM' : '5 PM - 7 PM'}</div>
                        </div>
                    </div>

                    <div style="background: #fbf5df; border-left: 4px solid #d4af37; padding: 12px 16px; border-radius: 6px; font-size: 0.88rem; color: #4a0d17; margin-bottom: 18px;">
                        <strong>Mentor Remarks:</strong> "${escapeHTML(student.remarks)}"
                    </div>

                    <div style="display: flex; justify-content: flex-end; gap: 10px;">
                        ${student.paymentStatus === 'Paid' ? `
                            <button class="btn btn-outline-gold" style="padding: 6px 14px; font-size: 0.82rem;" onclick="openReceiptForStudent('${student.id}')">
                                Download Fee Receipt
                            </button>
                        ` : `
                            <button class="btn btn-primary" style="padding: 6px 14px; font-size: 0.82rem;" onclick="document.getElementById('payment').scrollIntoView({behavior: 'smooth'})">
                                Pay Dues (₹${student.tuitionFee + student.admissionFee})
                            </button>
                        `}
                        <button class="btn btn-primary" style="padding: 6px 14px; font-size: 0.82rem;" onclick="loadCertForStudent('${student.id}')">
                            View Official Certificate
                        </button>
                    </div>
                </div>
            `;
        });
    }
}

// ==========================================
// 12. Saturday Schedule Filter
// ==========================================
function initScheduleFilter() {
    const buttons = document.querySelectorAll('.sched-filter-btn');
    const cards = document.querySelectorAll('.schedule-card');

    buttons.forEach(btn => {
        btn.addEventListener('click', () => {
            buttons.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            const filter = btn.getAttribute('data-filter');
            cards.forEach(card => {
                if (filter === 'all' || card.getAttribute('data-discipline-tag').includes(filter)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    });
}

// ==========================================
// 13. Registration Modal & Modals Handling
// ==========================================
let activeRegistrationStudent = null;

function openBatchPaymentModal(stu) {
    activeRegistrationStudent = stu;
    const modal = document.getElementById('batchPaymentModal');
    if (!modal) return;

    const studentNameEl = document.getElementById('batchPayStudentName');
    const studentInfoEl = document.getElementById('batchPayStudentInfo');
    const discInfoEl = document.getElementById('batchPayDisciplineInfo');
    const batchInfoEl = document.getElementById('batchPayBatchInfo');
    const amountTextEl = document.getElementById('batchPayAmountText');
    const directUpiLink = document.getElementById('batchDirectUpiLink');
    const qrContainer = document.getElementById('batchModalQRCode');

    if (studentNameEl) studentNameEl.textContent = stu.name;
    if (studentInfoEl) studentInfoEl.textContent = `${stu.name} (${stu.id})`;
    if (discInfoEl) discInfoEl.textContent = `${stu.discipline} (${stu.mode} Mode)`;
    if (batchInfoEl) batchInfoEl.textContent = stu.batch;
    if (amountTextEl) amountTextEl.textContent = '₹449/-';

    const upiUri = `upi://pay?pa=education.saha7@oksbi&pn=Sushmita%20Saha&am=449&cu=INR&tn=Batch%20Admission%20Fee%20${encodeURIComponent(stu.name)}`;
    if (directUpiLink) directUpiLink.href = upiUri;

    // Render dynamic QR Code
    if (qrContainer && window.QRCode) {
        qrContainer.innerHTML = '';
        new QRCode(qrContainer, {
            text: upiUri,
            width: 180,
            height: 180,
            colorDark: "#3b0912",
            colorLight: "#ffffff"
        });
    }

    // Reset UTR input
    const utrInput = document.getElementById('batchUtrNumber');
    if (utrInput) utrInput.value = '';

    modal.classList.add('active');
}

function initModals() {
    const regModal = document.getElementById('registrationModal');
    const openRegBtns = document.querySelectorAll('.open-register-modal-btn');
    const closeBtns = document.querySelectorAll('.modal-close-btn');

    // General Open Admission modal buttons
    openRegBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const noticeEl = document.getElementById('regBatchNotice');
            if (noticeEl) noticeEl.style.display = 'none';
            if (regModal) regModal.classList.add('active');
        });
    });

    // Direct Batch Registration buttons from #schedule (No Google Form Required)
    const batchRegBtns = document.querySelectorAll('.register-batch-btn');
    batchRegBtns.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const discipline = btn.getAttribute('data-discipline') || 'Harmonium';
            const batch = btn.getAttribute('data-batch') || '';
            const title = btn.getAttribute('data-title') || batch;

            const discSelect = document.getElementById('regDiscipline');
            const batchSelect = document.getElementById('regBatch');
            const noticeEl = document.getElementById('regBatchNotice');
            const noticeText = document.getElementById('regBatchNoticeText');

            if (discSelect) discSelect.value = discipline;
            if (batchSelect && batch) batchSelect.value = batch;
            if (noticeEl && noticeText) {
                noticeText.textContent = `Direct Website Registration for: ${title} (No Google Form Required)`;
                noticeEl.style.display = 'block';
            }

            if (regModal) regModal.classList.add('active');
        });
    });

    closeBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('active'));
        });
    });

    // Close on clicking backdrop
    document.querySelectorAll('.modal-overlay').forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.classList.remove('active');
            }
        });
    });

    // Registration Form Submission -> Opens On-Website UPI QR Payment Modal
    const regForm = document.getElementById('admissionRegisterForm');
    if (regForm) {
        regForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const name = document.getElementById('regStudentName').value;
            const phone = document.getElementById('regStudentPhone').value;
            const email = document.getElementById('regStudentEmail').value;
            const guardian = document.getElementById('regGuardianName').value;
            const discipline = document.getElementById('regDiscipline').value;
            const mode = document.getElementById('regMode').value;
            const batch = document.getElementById('regBatch').value;

            const studentPayload = {
                name,
                phone,
                email,
                guardian,
                discipline,
                mode,
                batch,
                paymentStatus: "Pending"
            };

            let newStu = null;
            if (window.saptavinaAPI) {
                newStu = await window.saptavinaAPI.registerStudent(studentPayload);
            } else if (window.studentDb) {
                newStu = window.studentDb.addStudent(studentPayload);
            }

            await filterAndRenderStudents();
            regModal.classList.remove('active');

            // Open the Direct Batch Payment Modal with dynamic UPI QR Code
            openBatchPaymentModal(newStu);
        });
    }

    // Copy UPI ID button in Payment Modal
    const copyUpiBtn = document.getElementById('batchCopyUpiBtn');
    if (copyUpiBtn) {
        copyUpiBtn.addEventListener('click', () => {
            navigator.clipboard.writeText('education.saha7@oksbi').then(() => {
                copyUpiBtn.innerHTML = '<i class="fas fa-check"></i> Copied!';
                setTimeout(() => {
                    copyUpiBtn.innerHTML = '<i class="fas fa-copy"></i> Copy UPI ID';
                }, 2000);
            }).catch(() => {
                alert('UPI ID: education.saha7@oksbi');
            });
        });
    }

    // Step 2: UTR Submission & Official Receipt Confirmation
    const batchPayConfirmForm = document.getElementById('batchPaymentConfirmForm');
    if (batchPayConfirmForm) {
        batchPayConfirmForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const utr = document.getElementById('batchUtrNumber').value.trim();
            if (!utr) return;

            if (activeRegistrationStudent) {
                const stuId = activeRegistrationStudent.id;
                if (window.saptavinaAPI) {
                    await window.saptavinaAPI.updatePaymentStatus(stuId, utr, 'UPI QR');
                } else if (window.studentDb) {
                    const stu = window.studentDb.getById(stuId);
                    if (stu) {
                        stu.paymentStatus = 'Paid';
                        stu.lastTxnId = utr;
                        stu.lastPaymentMode = 'UPI QR';
                        stu.lastPaymentDate = new Date().toISOString().split('T')[0];
                        window.studentDb.save();
                    }
                }

                await filterAndRenderStudents();

                const batchModal = document.getElementById('batchPaymentModal');
                if (batchModal) batchModal.classList.remove('active');

                // Open official receipt modal with verification details
                window.openReceiptForStudent(stuId, utr, 449);
            }
        });
    }

    // Print Receipt from Modal Button
    const modalPrintBtn = document.getElementById('printReceiptFromModalBtn');
    if (modalPrintBtn) {
        modalPrintBtn.addEventListener('click', () => {
            const printCard = document.getElementById('modalPrintableReceipt');
            if (printCard) {
                printCard.classList.add('printable-area');
                window.print();
                printCard.classList.remove('printable-area');
            } else {
                window.print();
            }
        });
    }
}

// ==========================================
// Utility Helpers
// ==========================================
function formatDate(dateStr) {
    if (!dateStr) return '';
    const d = new Date(dateStr);
    return d.toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
    });
}

function escapeHTML(str) {
    if (!str) return '';
    return str.replace(/[&<>'"]/g, tag => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        "'": '&#39;',
        '"': '&quot;'
    }[tag] || tag));
}

function hashString(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
        hash = ((hash << 5) - hash) + str.charCodeAt(i);
        hash |= 0;
    }
    return hash;
}
