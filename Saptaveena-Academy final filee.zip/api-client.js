/**
 * Saptavina Academy - Frontend API Client
 * Connects the UI to FastAPI + MongoDB backend (http://localhost:8000/api)
 * Gracefully falls back to client-side database when backend server is offline.
 */

class SaptavinaAPIClient {
    constructor(baseURL = "http://localhost:8000/api") {
        this.baseURL = baseURL;
        this.backendAvailable = null; // null = untracked, true = online, false = offline
        this.checkBackendHealth();
    }

    async checkBackendHealth() {
        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 1500);
            const res = await fetch(`${this.baseURL}/health`, { signal: controller.signal });
            clearTimeout(timeoutId);
            if (res.ok) {
                const data = await res.json();
                this.backendAvailable = true;
                console.info("Connected to Saptavina Academy FastAPI Backend:", data);
                this.notifyBackendStatus(true);
                return true;
            }
        } catch (e) {
            this.backendAvailable = false;
            console.warn("FastAPI backend not running at", this.baseURL, "- Using local database adapter.");
            this.notifyBackendStatus(false);
            return false;
        }
        return false;
    }

    notifyBackendStatus(isOnline) {
        // Dispatches event so UI components can display live DB connection badge
        const evt = new CustomEvent('saptavina:backend-status', { detail: { isOnline } });
        window.dispatchEvent(evt);
    }

    // ==============================================================
    // Student Endpoints
    // ==============================================================

    async getStudents(filters = {}) {
        const { discipline = 'all', mode = 'all', payment_status = 'all', search = '' } = filters;
        if (this.backendAvailable) {
            try {
                const params = new URLSearchParams({ discipline, mode, payment_status });
                if (search) params.append('search', search);
                const res = await fetch(`${this.baseURL}/students?${params.toString()}`);
                if (res.ok) {
                    return await res.json();
                }
            } catch (err) {
                console.error("API error fetching students:", err);
            }
        }
        // Fallback to client database
        return window.studentDb ? window.studentDb.filter(discipline, mode, payment_status, search) : [];
    }

    async getStudentById(studentId) {
        if (this.backendAvailable) {
            try {
                const res = await fetch(`${this.baseURL}/students/${encodeURIComponent(studentId)}`);
                if (res.ok) return await res.json();
            } catch (err) {
                console.error("API error fetching student:", err);
            }
        }
        return window.studentDb ? window.studentDb.getById(studentId) : null;
    }

    async getStudentByPhone(phone) {
        if (this.backendAvailable) {
            try {
                const res = await fetch(`${this.baseURL}/students/by-phone/${encodeURIComponent(phone)}`);
                if (res.ok) return await res.json();
            } catch (err) {
                console.error("API error searching student by phone:", err);
            }
        }
        return window.studentDb ? window.studentDb.getByPhone(phone) : null;
    }

    async registerStudent(studentData) {
        if (this.backendAvailable) {
            try {
                const res = await fetch(`${this.baseURL}/students`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        name: studentData.name,
                        phone: studentData.phone,
                        email: studentData.email || "",
                        guardian: studentData.guardian || "",
                        discipline: studentData.discipline,
                        mode: studentData.mode || "Offline",
                        batch: studentData.batch,
                        payment_status: studentData.paymentStatus || "Pending",
                        tuition_fee: 399,
                        admission_fee: 50
                    })
                });
                if (res.ok) {
                    const created = await res.json();
                    // Mirror in client DB for offline consistency
                    if (window.studentDb) window.studentDb.addStudent(created);
                    return created;
                }
            } catch (err) {
                console.error("API error registering student:", err);
            }
        }
        // Fallback
        return window.studentDb ? window.studentDb.addStudent(studentData) : null;
    }

    async updatePaymentStatus(studentId, txnId, paymentMode = 'UPI QR') {
        if (this.backendAvailable) {
            try {
                const res = await fetch(`${this.baseURL}/students/${encodeURIComponent(studentId)}/payment`, {
                    method: 'PATCH',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        payment_status: 'Paid',
                        payment_mode: paymentMode,
                        txn_id: txnId,
                        payment_date: new Date().toISOString().split('T')[0]
                    })
                });
                if (res.ok) {
                    const updated = await res.json();
                    if (window.studentDb) window.studentDb.updatePaymentStatus(studentId, 'Paid', paymentMode, txnId);
                    return updated;
                }
            } catch (err) {
                console.error("API error recording payment:", err);
            }
        }
        return window.studentDb ? window.studentDb.updatePaymentStatus(studentId, 'Paid', paymentMode, txnId) : null;
    }

    async getFinancialSummary() {
        if (this.backendAvailable) {
            try {
                const res = await fetch(`${this.baseURL}/financial-summary`);
                if (res.ok) return await res.json();
            } catch (err) {
                console.error("API error fetching financial summary:", err);
            }
        }
        return window.studentDb ? window.studentDb.getFinancialSummary() : null;
    }

    // ==============================================================
    // Events Endpoints
    // ==============================================================

    async getEvents() {
        if (this.backendAvailable) {
            try {
                const res = await fetch(`${this.baseURL}/events`);
                if (res.ok) return await res.json();
            } catch (err) {
                console.error("API error fetching events:", err);
            }
        }
        // Verified default events fallback
        return [
            {
                id: "EVT-2026-001",
                title: "Saptaveena Sangeet Utsav",
                type: "Annual Gala 2026",
                description: "Live stage concert featuring guitar ensembles, classical harmonium solos, and vocal duets under expert mentor guidance.",
                date: "Dec 2026",
                location: "Rabindra Okakura Bhavan, Kolkata",
                mode: "Offline Studio & Live Stream"
            },
            {
                id: "EVT-2026-002",
                title: '"Rang-O-Tulika" Annual Showcase',
                type: "Art Exhibition",
                description: "Curated gallery exhibition presenting sketches, acrylics, and watercolor portraits evaluated by Director Sushmita Saha.",
                date: "Nov 2026",
                location: "Saptaveena Gallery Hall • Mall Road, Kolkata",
                mode: "Offline Gallery & Virtual Room"
            },
            {
                id: "EVT-2026-003",
                title: "Inter-Batch Riff & Raga Cup",
                type: "Competition",
                description: "Friendly competitive performance rounds judged by faculty mentors with medals, certificates, and scholarship awards.",
                date: "Oct 2026",
                location: "Hybrid Event (Studio + Online)",
                mode: "Hybrid Event (Studio + Online)"
            }
        ];
    }

    // ==============================================================
    // Google Gemini AI Academic Mentor Endpoints
    // ==============================================================

    async askMentorAI(query, discipline = null, studentName = null) {
        if (this.backendAvailable) {
            try {
                const res = await fetch(`${this.baseURL}/ai/ask-mentor`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ query, discipline, student_name: studentName })
                });
                if (res.ok) {
                    const data = await res.json();
                    return data.answer;
                }
            } catch (err) {
                console.error("Gemini API endpoint error:", err);
            }
        }
        // Client-side fallback response
        return `Namaste! For ${discipline || 'Music & Arts'} questions, practice regularly under our expert mentors. Join our Saturday sessions (Harmonium 10-12, Art 12-2, Guitar 5-7) guided by Director Sushmita Saha at 2/12 Moksh Apartment, Kolkata.`;
    }
}

// Global API Client Instance
window.saptavinaAPI = new SaptavinaAPIClient();
