# 🎻 Saptaveena Academy (Music & Arts Institute)

> **Official Website Repository for Saptaveena Academy (Saptavina Academy), Kolkata.**  
> Founded & Guided by **Director & Chief Academic Mentor: Sushmita Saha**.

---

## 🏛️ About Saptaveena Academy
Saptaveena Academy is a premier cultural and creative institute offering structured, beginner-friendly training across **Harmonium**, **Art & Fine Drawing**, and **Guitar** for all age groups in both **Offline (Kolkata Studio)** and **Online** modes.

### 📍 Academy Studio Address
`2/12 Moksh Apartment, K.B. Sarani, Mall Road, Kolkata - 700080`

---

## 📅 Saturday Timetable & Schedule
| Discipline | Saturday Timing | Mode | Focus Area |
|---|---|---|---|
| **Harmonium** | 10:00 AM – 12:00 PM | Offline & Online | Classical Swaras, Bilawal Thaat, Bhajans & Rabindra Sangeet |
| **Art & Drawing** | 12:00 PM – 2:00 PM | Offline & Online | Sketching, Acrylics, Watercolors, Canvas Composition |
| **Guitar** | 5:00 PM – 7:00 PM | Offline & Online | Acoustic Rhythms, Chords, Fingerpicking, Strumming Patterns |

---

## 💳 Verified Fee Structure
- **Monthly Tuition:** ₹399/- per month
- **One-Time Admission Fee:** ₹50/- (includes syllabus & student enrollment ID)
- **Total Initial Payment:** **₹449/-**
- **Official UPI ID:** `education.saha7@oksbi`
- **Bank:** State Bank of India (SBI)
- **Payee Name:** Sushmita Saha

---

## 🚀 How to Publish on GitHub Pages (Free Live Website)

1. **Upload Files to GitHub:**
   - Create a new public repository on GitHub (e.g. `saptaveena-academy`).
   - Drag and drop all the files from this folder directly into the repository and click **Commit changes**.
2. **Enable GitHub Pages:**
   - In your repository, click **Settings** (top navigation tab).
   - In the left sidebar, click **Pages**.
   - Under **Build and deployment > Source**, select **Deploy from a branch**.
   - Under **Branch**, select `main` (or `master`) and folder `/ (root)`.
   - Click **Save**.
3. **Your Live Website Link:**
   - In 1–2 minutes, your website will be live at:  
     `https://<your-github-username>.github.io/<repository-name>/`
