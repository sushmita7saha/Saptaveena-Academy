/**
 * Saptaveena Academy - Unified Student Database & Finance Ledger
 * Supports online and offline students across Guitar, Art & Drawing, and Harmonium.
 */

const SAPTAVEENA_INITIAL_STUDENTS = [
    {
        id: "SAPTA-2026-001",
        name: "Debanjan Roy",
        discipline: "Guitar",
        mode: "Offline",
        batch: "Saturday Evening 3 (5:00 PM – 7:00 PM)",
        phone: "9830124578",
        email: "debanjan.roy@gmail.com",
        guardian: "Sunil Roy",
        joinDate: "2026-01-10",
        tuitionFee: 399,
        admissionFee: 50,
        paymentStatus: "Paid",
        lastPaymentDate: "2026-11-02",
        lastPaymentMode: "UPI QR",
        lastTxnId: "UPI/261102983012",
        attendancePercent: 94,
        classesAttended: 16,
        totalClasses: 17,
        examScore: 92,
        grade: "Distinction",
        certificateIssued: true,
        certificateId: "SAPTA-CERT-2026-G01",
        remarks: "Exceptional fingerpicking rhythm and barre chord transitions under expert mentor guidance."
    },
    {
        id: "SAPTA-2026-002",
        name: "Ananya Ghosh",
        discipline: "Art & Drawing",
        mode: "Offline",
        batch: "Saturday Morning 2 (12:00 PM – 2:00 PM)",
        phone: "9163554412",
        email: "ananya.ghosh22@outlook.com",
        guardian: "Purnima Ghosh",
        joinDate: "2026-02-14",
        tuitionFee: 399,
        admissionFee: 50,
        paymentStatus: "Paid",
        lastPaymentDate: "2026-11-05",
        lastPaymentMode: "Bank Transfer",
        lastTxnId: "NEFT/SBIN8892110",
        attendancePercent: 100,
        classesAttended: 17,
        totalClasses: 17,
        examScore: 96,
        grade: "Distinction",
        certificateIssued: true,
        certificateId: "SAPTA-CERT-2026-A02",
        remarks: "Exquisite watercolor blending technique and landscape perspective evaluated by Director Sushmita Saha."
    },
    {
        id: "SAPTA-2026-003",
        name: "Souvik Mukherjee",
        discipline: "Harmonium",
        mode: "Offline",
        batch: "Saturday Morning 1 (10:00 AM – 12:00 PM)",
        phone: "9831998871",
        email: "souvik.mukh@gmail.com",
        guardian: "Bimal Mukherjee",
        joinDate: "2026-01-20",
        tuitionFee: 399,
        admissionFee: 50,
        paymentStatus: "Paid",
        lastPaymentDate: "2026-11-01",
        lastPaymentMode: "UPI Direct",
        lastTxnId: "UPI/261101983199",
        attendancePercent: 88,
        classesAttended: 15,
        totalClasses: 17,
        examScore: 89,
        grade: "A+",
        certificateIssued: true,
        certificateId: "SAPTA-CERT-2026-H03",
        remarks: "Grasping Raga Yaman Aaroh-Avroh flawlessly with proper meend guided by an expert mentor."
    },
    {
        id: "SAPTA-2026-004",
        name: "Sneha Sengupta",
        discipline: "Guitar",
        mode: "Online",
        batch: "Saturday Evening 3 (5:00 PM – 7:00 PM)",
        phone: "9874112233",
        email: "sneha.sengupta@yahoo.com",
        guardian: "Subhash Sengupta",
        joinDate: "2026-03-01",
        tuitionFee: 399,
        admissionFee: 50,
        paymentStatus: "Paid",
        lastPaymentDate: "2026-11-04",
        lastPaymentMode: "UPI QR",
        lastTxnId: "UPI/261104987411",
        attendancePercent: 92,
        classesAttended: 14,
        totalClasses: 15,
        examScore: 88,
        grade: "A+",
        certificateIssued: true,
        certificateId: "SAPTA-CERT-2026-G04",
        remarks: "Active in virtual classroom chord breakdown sessions."
    },
    {
        id: "SAPTA-2026-005",
        name: "Ritobroto Das",
        discipline: "Art & Drawing",
        mode: "Online",
        batch: "Saturday Morning 2 (12:00 PM – 2:00 PM)",
        phone: "9433221199",
        email: "ritobroto.arts@gmail.com",
        guardian: "Tanmay Das",
        joinDate: "2026-04-12",
        tuitionFee: 399,
        admissionFee: 50,
        paymentStatus: "Pending",
        lastPaymentDate: "2026-10-06",
        lastPaymentMode: "UPI Direct",
        lastTxnId: "UPI/261006943322",
        attendancePercent: 85,
        classesAttended: 11,
        totalClasses: 13,
        examScore: 82,
        grade: "A",
        certificateIssued: false,
        certificateId: null,
        remarks: "Great shading on charcoal portraits; pending November tuition."
    },
    {
        id: "SAPTA-2026-006",
        name: "Ishita Banerjee",
        discipline: "Harmonium",
        mode: "Online",
        batch: "Saturday Morning 1 (10:00 AM – 12:00 PM)",
        phone: "9836551122",
        email: "ishita.banerjee@rediffmail.com",
        guardian: "Alok Banerjee",
        joinDate: "2026-02-05",
        tuitionFee: 399,
        admissionFee: 50,
        paymentStatus: "Paid",
        lastPaymentDate: "2026-11-03",
        lastPaymentMode: "Bank Transfer",
        lastTxnId: "IMPS/261103983655",
        attendancePercent: 96,
        classesAttended: 16,
        totalClasses: 16,
        examScore: 94,
        grade: "Distinction",
        certificateIssued: true,
        certificateId: "SAPTA-CERT-2026-H06",
        remarks: "Excellent taan execution and harmonium accompaniment for Rabindra Sangeet."
    },
    {
        id: "SAPTA-2026-007",
        name: "Ayan Bhattacharya",
        discipline: "Guitar",
        mode: "Offline",
        batch: "Saturday Evening 3 (5:00 PM – 7:00 PM)",
        phone: "9163009988",
        email: "ayan.bhatta@gmail.com",
        guardian: "Dipak Bhattacharya",
        joinDate: "2026-05-18",
        tuitionFee: 399,
        admissionFee: 50,
        paymentStatus: "Pending",
        lastPaymentDate: "2026-09-30",
        lastPaymentMode: "UPI QR",
        lastTxnId: "UPI/260930916300",
        attendancePercent: 78,
        classesAttended: 9,
        totalClasses: 12,
        examScore: 79,
        grade: "B+",
        certificateIssued: false,
        certificateId: null,
        remarks: "Practicing finger independence; reminder sent for fee clearance."
    },
    {
        id: "SAPTA-2026-008",
        name: "Poulomi Chatterjee",
        discipline: "Art & Drawing",
        mode: "Offline",
        batch: "Saturday Morning 2 (12:00 PM – 2:00 PM)",
        phone: "9830441155",
        email: "poulomi.c@gmail.com",
        guardian: "Sharmila Chatterjee",
        joinDate: "2026-03-22",
        tuitionFee: 399,
        admissionFee: 50,
        paymentStatus: "Paid",
        lastPaymentDate: "2026-11-07",
        lastPaymentMode: "UPI QR",
        lastTxnId: "UPI/261107983044",
        attendancePercent: 91,
        classesAttended: 13,
        totalClasses: 14,
        examScore: 91,
        grade: "Distinction",
        certificateIssued: true,
        certificateId: "SAPTA-CERT-2026-A08",
        remarks: "Selected for Saptaveena Annual Art Exhibition 2026."
    },
    {
        id: "SAPTA-2026-009",
        name: "Kunal Basu",
        discipline: "Harmonium",
        mode: "Offline",
        batch: "Saturday Morning 1 (10:00 AM – 12:00 PM)",
        phone: "9432119988",
        email: "kunal.basu@gmail.com",
        guardian: "Tapas Basu",
        joinDate: "2026-06-01",
        tuitionFee: 399,
        admissionFee: 50,
        paymentStatus: "Overdue",
        lastPaymentDate: "2026-08-25",
        lastPaymentMode: "Cash/Bank",
        lastTxnId: "CSH/260825943211",
        attendancePercent: 70,
        classesAttended: 7,
        totalClasses: 10,
        examScore: 73,
        grade: "B",
        certificateIssued: false,
        certificateId: null,
        remarks: "Needs practice in Komal Dhaivat swaras; 2 months fee pending."
    },
    {
        id: "SAPTA-2026-010",
        name: "Tanushree Paul",
        discipline: "Guitar",
        mode: "Online",
        batch: "Saturday Evening 3 (5:00 PM – 7:00 PM)",
        phone: "9163882200",
        email: "tanushree.p@gmail.com",
        guardian: "Gourab Paul",
        joinDate: "2026-07-15",
        tuitionFee: 399,
        admissionFee: 50,
        paymentStatus: "Paid",
        lastPaymentDate: "2026-11-01",
        lastPaymentMode: "UPI QR",
        lastTxnId: "UPI/261101916388",
        attendancePercent: 95,
        classesAttended: 8,
        totalClasses: 8,
        examScore: 90,
        grade: "Distinction",
        certificateIssued: true,
        certificateId: "SAPTA-CERT-2026-G10",
        remarks: "Fast learner in syncopated strumming and arpeggio sequences."
    },
    {
        id: "SAPTA-2026-011",
        name: "Arnab Majumdar",
        discipline: "Art & Drawing",
        mode: "Online",
        batch: "Saturday Morning 2 (12:00 PM – 2:00 PM)",
        phone: "9875001144",
        email: "arnab.majumdar@gmail.com",
        guardian: "Debasish Majumdar",
        joinDate: "2026-08-01",
        tuitionFee: 399,
        admissionFee: 50,
        paymentStatus: "Paid",
        lastPaymentDate: "2026-11-06",
        lastPaymentMode: "UPI Direct",
        lastTxnId: "UPI/261106987500",
        attendancePercent: 89,
        classesAttended: 6,
        totalClasses: 7,
        examScore: 87,
        grade: "A+",
        certificateIssued: true,
        certificateId: "SAPTA-CERT-2026-A11",
        remarks: "Showed vibrant color palettes in virtual oil pastel submission guided by an expert mentor."
    },
    {
        id: "SAPTA-2026-012",
        name: "Mousumi Halder",
        discipline: "Harmonium",
        mode: "Offline",
        batch: "Saturday Morning 1 (10:00 AM – 12:00 PM)",
        phone: "9831776655",
        email: "mousumi.h@gmail.com",
        guardian: "Bratin Halder",
        joinDate: "2026-01-18",
        tuitionFee: 399,
        admissionFee: 50,
        paymentStatus: "Paid",
        lastPaymentDate: "2026-11-03",
        lastPaymentMode: "UPI QR",
        lastTxnId: "UPI/261103983177",
        attendancePercent: 97,
        classesAttended: 16,
        totalClasses: 17,
        examScore: 95,
        grade: "Distinction",
        certificateIssued: true,
        certificateId: "SAPTA-CERT-2026-H12",
        remarks: "Command over Teentaal harmonium bols and classical Bhajans under expert mentor guidance."
    }
];

class StudentDatabase {
    constructor() {
        this.STORAGE_KEY = 'saptaveena_students_db_v2';
        this.students = this.loadStudents();
    }

    loadStudents() {
        try {
            const raw = localStorage.getItem(this.STORAGE_KEY);
            if (raw) {
                const parsed = JSON.parse(raw);
                if (Array.isArray(parsed) && parsed.length > 0) {
                    return parsed;
                }
            }
        } catch (e) {
            console.warn("Could not read from localStorage, using initial seed data", e);
        }
        this.saveStudents(SAPTAVEENA_INITIAL_STUDENTS);
        return [...SAPTAVEENA_INITIAL_STUDENTS];
    }

    saveStudents(data = this.students) {
        try {
            localStorage.setItem(this.STORAGE_KEY, JSON.stringify(data));
        } catch (e) {
            console.error("Failed to save students to localStorage", e);
        }
    }

    getAll() {
        return this.students;
    }

    getById(id) {
        return this.students.find(s => s.id === id);
    }

    getByPhone(phone) {
        const clean = phone.replace(/\D/g, '');
        return this.students.find(s => s.phone.includes(clean));
    }

    filter(discipline = 'all', mode = 'all', payment = 'all', searchQuery = '') {
        return this.students.filter(s => {
            const matchDiscipline = discipline === 'all' || s.discipline.toLowerCase() === discipline.toLowerCase();
            const matchMode = mode === 'all' || s.mode.toLowerCase() === mode.toLowerCase();
            const matchPayment = payment === 'all' || s.paymentStatus.toLowerCase() === payment.toLowerCase();
            
            let matchSearch = true;
            if (searchQuery.trim()) {
                const q = searchQuery.toLowerCase().trim();
                matchSearch = s.name.toLowerCase().includes(q) ||
                              s.id.toLowerCase().includes(q) ||
                              s.phone.includes(q) ||
                              s.email.toLowerCase().includes(q);
            }
            return matchDiscipline && matchMode && matchPayment && matchSearch;
        });
    }

    addStudent(newStudent) {
        const count = this.students.length + 1;
        const code = newStudent.discipline === 'Guitar' ? 'G' : newStudent.discipline === 'Harmonium' ? 'H' : 'A';
        const id = `SAPTA-2026-${String(count).padStart(3, '0')}`;
        
        const record = {
            id: id,
            name: newStudent.name,
            discipline: newStudent.discipline,
            mode: newStudent.mode || "Offline",
            batch: newStudent.batch || "Saturday Morning 1 (10:00 AM – 12:00 PM)",
            phone: newStudent.phone,
            email: newStudent.email || "",
            guardian: newStudent.guardian || "",
            joinDate: new Date().toISOString().split('T')[0],
            tuitionFee: 399,
            admissionFee: 50,
            paymentStatus: newStudent.paymentStatus || "Pending",
            lastPaymentDate: newStudent.paymentStatus === 'Paid' ? new Date().toISOString().split('T')[0] : "",
            lastPaymentMode: newStudent.lastPaymentMode || "UPI QR",
            lastTxnId: newStudent.paymentStatus === 'Paid' ? `UPI/${Date.now().toString().slice(-10)}` : "",
            attendancePercent: 100,
            classesAttended: 1,
            totalClasses: 1,
            examScore: null,
            grade: "In Progress",
            certificateIssued: false,
            certificateId: null,
            remarks: "Newly enrolled student. Welcome to Saptaveena Academy!"
        };

        this.students.unshift(record);
        this.saveStudents();
        return record;
    }

    updatePaymentStatus(id, newStatus, paymentMode = 'UPI QR', txnId = '') {
        const student = this.getById(id);
        if (student) {
            student.paymentStatus = newStatus;
            if (newStatus === 'Paid') {
                student.lastPaymentDate = new Date().toISOString().split('T')[0];
                student.lastPaymentMode = paymentMode;
                student.lastTxnId = txnId || `UPI/${Date.now().toString().slice(-10)}`;
            }
            this.saveStudents();
            return student;
        }
        return null;
    }

    recordAttendance(id, present = true) {
        const student = this.getById(id);
        if (student) {
            student.totalClasses = (student.totalClasses || 0) + 1;
            if (present) {
                student.classesAttended = (student.classesAttended || 0) + 1;
            }
            student.attendancePercent = Math.round((student.classesAttended / student.totalClasses) * 100);
            this.saveStudents();
            return student;
        }
        return null;
    }

    issueCertificate(id, grade = "Distinction") {
        const student = this.getById(id);
        if (student) {
            const discLetter = student.discipline.charAt(0).toUpperCase();
            student.certificateIssued = true;
            student.grade = grade;
            student.certificateId = `SAPTA-CERT-2026-${discLetter}${student.id.split('-').pop()}`;
            this.saveStudents();
            return student;
        }
        return null;
    }

    deleteStudent(id) {
        this.students = this.students.filter(s => s.id !== id);
        this.saveStudents();
        return true;
    }

    clearAll() {
        this.students = [];
        this.saveStudents([]);
        return true;
    }

    resetToSeed() {
        this.students = [...SAPTAVEENA_INITIAL_STUDENTS];
        this.saveStudents();
        return this.students;
    }

    getFinancialSummary() {
        let totalCollected = 0;
        let pendingCount = 0;
        let paidCount = 0;
        let overdueCount = 0;

        this.students.forEach(s => {
            if (s.paymentStatus === 'Paid') {
                paidCount++;
                totalCollected += (s.tuitionFee + s.admissionFee);
            } else if (s.paymentStatus === 'Pending') {
                pendingCount++;
            } else if (s.paymentStatus === 'Overdue') {
                overdueCount++;
            }
        });

        return {
            totalStudents: this.students.length,
            paidCount,
            pendingCount,
            overdueCount,
            totalCollected,
            expectedMonthly: this.students.length * 399
        };
    }
}

// Global database instance
window.studentDb = new StudentDatabase();
